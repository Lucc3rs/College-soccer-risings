// React hook for managing game state with localStorage persistence

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { type GameState, type Position, type Season } from '@/types/game';
import { getStartingStats, calculateXPForLevel } from '@/lib/game-engine';
import { INITIAL_ACHIEVEMENTS, COLLEGES } from '@/lib/game-data';

const STORAGE_KEY = 'soccer-rpg-save';

const createInitialState = (name: string, position: Position, highSchool = 'Lincoln High'): GameState => ({
  profile: {
    name,
    position,
    appearance: {
      skinTone: 0,
      hairStyle: 0,
      hairColor: 0,
    },
    college: 'TBD',
    highSchool,
  },
  stats: getStartingStats(position),
  level: 1,
  xp: 0,
  xpToNextLevel: calculateXPForLevel(1),
  gpa: 3.5,
  season: 'High School Senior',
  phase: 'Regular Season',
  week: 1,
  isStarter: true,
  isHighSchool: true,
  currency: {
    coins: 500,
    reputationPoints: 0,
    nilMoney: 0,
  },
  energy: 100,
  maxEnergy: 100,
  weeklyActivitiesDone: {
    training: false,
    classes: false,
    match: false,
  },
  currentScholarship: 'none',
  scholarshipOffers: [],
  activeNILDeals: [],
  availableNILDeals: [],
  reputation: 0,
  teamChemistry: 50,
  coachTrust: 50,
  fanSupport: 50,
  matchHistory: [],
  choiceHistory: [],
  achievements: INITIAL_ACHIEVEMENTS,
  unlockedTraits: [],
  skillPoints: 0,
  transferHistory: [],
  inventory: [],
  seasonSchedule: [],
  regularSeasonWins: 0,
  regularSeasonLosses: 0,
  regularSeasonTies: 0,
  socialMedia: [],
  streaming: [],
  brandPartnerships: [],
  mediaAppearances: [],
  contentCreationSkill: 0,
});

interface GameContextType {
  gameState: GameState | null;
  updateGameState: (updates: Partial<GameState>) => void;
  startNewGame: (name: string, position: Position, highSchool?: string) => void;
  resetGame: () => void;
  saveGame: () => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider = ({ children }: { children: ReactNode }) => {
  const [gameState, setGameState] = useState<GameState | null>(null);

  // Load game on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const loadedState = JSON.parse(saved);
        // Handle backward compatibility for old saves without seasonSchedule
        if (!loadedState.seasonSchedule) {
          loadedState.seasonSchedule = [];
        }
        if (loadedState.regularSeasonWins === undefined) {
          loadedState.regularSeasonWins = 0;
        }
        if (loadedState.regularSeasonLosses === undefined) {
          loadedState.regularSeasonLosses = 0;
        }
        if (loadedState.regularSeasonTies === undefined) {
          loadedState.regularSeasonTies = 0;
        }
        if (!loadedState.socialMedia) {
          loadedState.socialMedia = [];
        }
        if (!loadedState.streaming) {
          loadedState.streaming = [];
        }
        if (!loadedState.brandPartnerships) {
          loadedState.brandPartnerships = [];
        }
        if (!loadedState.mediaAppearances) {
          loadedState.mediaAppearances = [];
        }
        if (loadedState.contentCreationSkill === undefined) {
          loadedState.contentCreationSkill = 0;
        }
        setGameState(loadedState);
      } catch (e) {
        console.error('Failed to load save:', e);
      }
    }
  }, []);

  // Auto-save on state change
  useEffect(() => {
    if (gameState) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(gameState));
    }
  }, [gameState]);

  const updateGameState = (updates: Partial<GameState>) => {
    setGameState(prev => prev ? { ...prev, ...updates } : null);
  };

  const startNewGame = (name: string, position: Position, highSchool?: string) => {
    const newState = createInitialState(name, position, highSchool);
    setGameState(newState);
  };

  const resetGame = () => {
    localStorage.removeItem(STORAGE_KEY);
    setGameState(null);
  };

  const saveGame = () => {
    if (gameState) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(gameState));
    }
  };

  return (
    <GameContext.Provider value={{ gameState, updateGameState, startNewGame, resetGame, saveGame }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGameState = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGameState must be used within GameProvider');
  }
  return context;
};
