// Main game component

import { GameProvider, useGameState } from '@/hooks/useGameState';
import { PlayerCreation } from '@/components/PlayerCreation';
import { GameDashboard } from '@/components/GameDashboard';

const GameContent = () => {
  const { gameState, startNewGame } = useGameState();

  if (!gameState) {
    return <PlayerCreation onComplete={startNewGame} />;
  }

  return <GameDashboard />;
};

export const SoccerCareerRPG = () => {
  return (
    <GameProvider>
      <GameContent />
    </GameProvider>
  );
};
