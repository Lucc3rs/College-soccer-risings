// Player creation screen

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { type Position } from '@/types/game';

const POSITIONS: { value: Position; label: string; description: string }[] = [
  { value: 'ST', label: 'Striker', description: 'Score goals, high shooting & pace' },
  { value: 'CAM', label: 'Attacking Mid', description: 'Create chances, passing & dribbling' },
  { value: 'CM', label: 'Center Mid', description: 'Balanced, all-around midfielder' },
  { value: 'CDM', label: 'Defensive Mid', description: 'Protect defense, tackling & strength' },
  { value: 'CB', label: 'Center Back', description: 'Stop attackers, defending & strength' },
  { value: 'GK', label: 'Goalkeeper', description: 'Save shots, reflexes & positioning' },
];

const HIGH_SCHOOLS = [
  'Lincoln High School',
  'Washington Prep',
  'Jefferson Academy',
  'Roosevelt High',
  'Madison Central',
  'Kennedy High School',
];

interface PlayerCreationProps {
  onComplete: (name: string, position: Position, highSchool?: string) => void;
}

export const PlayerCreation = ({ onComplete }: PlayerCreationProps) => {
  const [name, setName] = useState('');
  const [position, setPosition] = useState<Position | null>(null);
  const [highSchool, setHighSchool] = useState<string>(HIGH_SCHOOLS[0]);

  const handleSubmit = () => {
    if (name.trim() && position) {
      onComplete(name.trim(), position, highSchool);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-green-800 to-green-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold">College Soccer Career</CardTitle>
          <CardDescription className="text-lg">Create Your Player - Senior Year</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="player-name">Player Name</Label>
            <Input
              id="player-name"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="text-lg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="high-school">High School</Label>
            <select
              id="high-school"
              value={highSchool}
              onChange={(e) => setHighSchool(e.target.value)}
              className="w-full p-2 text-lg border rounded-md bg-white"
            >
              {HIGH_SCHOOLS.map((school) => (
                <option key={school} value={school}>
                  {school}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-3">
            <Label>Choose Your Position</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {POSITIONS.map((pos) => (
                <button
                  key={pos.value}
                  onClick={() => setPosition(pos.value)}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    position === pos.value
                      ? 'border-green-600 bg-green-50 shadow-lg'
                      : 'border-gray-200 hover:border-green-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="font-bold text-lg">{pos.label}</div>
                  <div className="text-sm text-gray-600 mt-1">{pos.description}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900 font-semibold">
              🏫 Starting as a High School Senior
            </p>
            <p className="text-xs text-blue-700 mt-1">
              Work hard to improve your skills and earn scholarship offers from top colleges!
            </p>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={!name.trim() || !position}
            className="w-full text-lg h-12"
            size="lg"
          >
            Begin Senior Year
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
