// Achievements screen

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { type GameState } from '@/types/game';
import { Trophy, Lock } from 'lucide-react';

interface AchievementsScreenProps {
  gameState: GameState;
}

export const AchievementsScreen = ({ gameState }: AchievementsScreenProps) => {
  const unlockedCount = gameState.achievements.filter(a => a.unlocked).length;
  const totalCount = gameState.achievements.length;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Career Achievements</CardTitle>
          <CardDescription>
            {unlockedCount} / {totalCount} unlocked
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Progress value={(unlockedCount / totalCount) * 100} className="h-3" />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {gameState.achievements.map((achievement) => (
          <Card key={achievement.id} className={achievement.unlocked ? 'border-green-500' : 'opacity-60'}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <CardTitle className="flex items-center gap-2 text-lg">
                  {achievement.unlocked ? (
                    <Trophy className="w-5 h-5 text-yellow-500" />
                  ) : (
                    <Lock className="w-5 h-5 text-slate-400" />
                  )}
                  {achievement.title}
                </CardTitle>
                {achievement.unlocked && <Badge variant="default">Unlocked</Badge>}
              </div>
              <CardDescription>{achievement.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span className="font-bold">
                    {achievement.progress} / {achievement.target}
                  </span>
                </div>
                <Progress value={(achievement.progress / achievement.target) * 100} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};
