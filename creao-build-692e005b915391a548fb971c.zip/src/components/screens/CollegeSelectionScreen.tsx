// College Selection Screen - After High School Senior Year

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { type GameState, type ScholarshipTier } from '@/types/game';
import { COLLEGES } from '@/lib/game-data';
import { Trophy, Star, GraduationCap } from 'lucide-react';

interface CollegeOffer {
  college: string;
  scholarshipTier: ScholarshipTier;
  description: string;
  requirements: string;
}

interface CollegeSelectionScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

export const CollegeSelectionScreen = ({ gameState, updateGameState }: CollegeSelectionScreenProps) => {
  // Generate college offers based on player performance
  const generateOffers = (): CollegeOffer[] => {
    const offers: CollegeOffer[] = [];
    const avgStat = Math.floor(Object.values(gameState.stats).reduce((a, b) => a + b, 0) / 9);
    const { reputation, gpa } = gameState;

    // Top tier colleges (full scholarship) - requires high stats
    if (avgStat >= 70 && reputation >= 80 && gpa >= 3.5) {
      const topColleges = ['Stanford', 'UCLA', 'North Carolina', 'Duke'];
      offers.push({
        college: topColleges[Math.floor(Math.random() * topColleges.length)],
        scholarshipTier: 'full',
        description: 'Elite program with national championship potential',
        requirements: 'Full athletic scholarship covering tuition, room & board',
      });
    }

    // Mid tier colleges (partial scholarship) - moderate stats
    if (avgStat >= 55 && reputation >= 50 && gpa >= 3.0) {
      const midColleges = ['Michigan', 'Virginia', 'Indiana', 'Georgetown'];
      const availableMid = midColleges.filter(c => !offers.find(o => o.college === c));
      if (availableMid.length > 0) {
        offers.push({
          college: availableMid[Math.floor(Math.random() * availableMid.length)],
          scholarshipTier: 'partial',
          description: 'Strong program with great coaching and facilities',
          requirements: 'Partial athletic scholarship covering 50% of costs',
        });
      }
    }

    // Lower tier colleges (walk-on) - anyone can join
    if (avgStat >= 40 && gpa >= 2.5) {
      const lowerColleges = ['Notre Dame', 'Wake Forest'];
      const availableLower = lowerColleges.filter(c => !offers.find(o => o.college === c));
      if (availableLower.length > 0) {
        offers.push({
          college: availableLower[Math.floor(Math.random() * availableLower.length)],
          scholarshipTier: 'none',
          description: 'Developing program looking for dedicated players',
          requirements: 'Walk-on opportunity - prove yourself to earn scholarship',
        });
      }
    }

    // Fallback - always have at least one option
    if (offers.length === 0) {
      offers.push({
        college: 'Wake Forest',
        scholarshipTier: 'none',
        description: 'Opportunity to develop your skills at the college level',
        requirements: 'Walk-on spot available - work hard to earn playing time',
      });
    }

    return offers;
  };

  const offers = generateOffers();

  const selectCollege = (offer: CollegeOffer) => {
    updateGameState({
      profile: {
        ...gameState.profile,
        college: offer.college,
      },
      currentScholarship: offer.scholarshipTier,
      season: 'Freshman',
      phase: 'Preseason',
      week: 1,
      isHighSchool: false,
      isStarter: offer.scholarshipTier === 'full', // Full scholarship means you start
      teamChemistry: 30, // Reset for new team
      coachTrust: offer.scholarshipTier === 'full' ? 60 : 40,
      fanSupport: offer.scholarshipTier === 'full' ? 50 : 30,
      weeklyActivitiesDone: {
        training: false,
        classes: false,
        match: false,
      },
    });
  };

  const avgStat = Math.floor(Object.values(gameState.stats).reduce((a, b) => a + b, 0) / 9);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0">
        <CardHeader>
          <CardTitle className="text-3xl text-white flex items-center gap-2">
            <GraduationCap className="w-8 h-8" />
            Congratulations, Graduate!
          </CardTitle>
          <CardDescription className="text-blue-100 text-lg">
            You've completed your senior year at {gameState.profile.highSchool}. Time to choose your college!
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 bg-white/10 rounded-lg p-4">
            <div className="text-center">
              <div className="text-sm text-blue-200">Final Stats</div>
              <div className="text-2xl font-bold">{avgStat} OVR</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-blue-200">GPA</div>
              <div className="text-2xl font-bold">{gameState.gpa.toFixed(2)}</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-blue-200">Reputation</div>
              <div className="text-2xl font-bold">{gameState.reputation}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-2xl font-bold text-white mb-4">College Offers ({offers.length})</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {offers.map((offer) => (
            <Card key={offer.college} className="bg-white dark:bg-slate-800 border-2 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl">{offer.college}</CardTitle>
                    <CardDescription>{offer.description}</CardDescription>
                  </div>
                  {offer.scholarshipTier === 'full' && (
                    <Trophy className="w-6 h-6 text-yellow-500" />
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Badge
                    variant={offer.scholarshipTier === 'full' ? 'default' : offer.scholarshipTier === 'partial' ? 'secondary' : 'outline'}
                    className="mb-2"
                  >
                    {offer.scholarshipTier === 'full' && '⭐ Full Scholarship'}
                    {offer.scholarshipTier === 'partial' && '💰 Partial Scholarship'}
                    {offer.scholarshipTier === 'none' && '🚶 Walk-On'}
                  </Badge>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{offer.requirements}</p>
                </div>

                <div className="bg-slate-50 dark:bg-slate-700 rounded p-3 space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Starting Position:</span>
                    <span className="font-semibold">{offer.scholarshipTier === 'full' ? 'Yes' : 'Bench'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Coach Trust:</span>
                    <span className="font-semibold">{offer.scholarshipTier === 'full' ? 'High' : 'Medium'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Prestige:</span>
                    <span className="font-semibold flex items-center gap-1">
                      {offer.scholarshipTier === 'full' && <><Star className="w-3 h-3 fill-yellow-400 text-yellow-400" /><Star className="w-3 h-3 fill-yellow-400 text-yellow-400" /><Star className="w-3 h-3 fill-yellow-400 text-yellow-400" /></>}
                      {offer.scholarshipTier === 'partial' && <><Star className="w-3 h-3 fill-yellow-400 text-yellow-400" /><Star className="w-3 h-3 fill-yellow-400 text-yellow-400" /></>}
                      {offer.scholarshipTier === 'none' && <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />}
                    </span>
                  </div>
                </div>

                <Button
                  onClick={() => selectCollege(offer)}
                  className="w-full"
                  variant={offer.scholarshipTier === 'full' ? 'default' : 'outline'}
                >
                  {offer.scholarshipTier === 'full' ? '🏆 Accept Full Scholarship' : 'Join ' + offer.college}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Card className="bg-blue-50 dark:bg-blue-900 border-blue-200 dark:border-blue-700">
        <CardContent className="pt-6">
          <p className="text-sm text-blue-900 dark:text-blue-100">
            <strong>💡 Tip:</strong> Your high school performance determines which colleges recruit you.
            Higher stats, reputation, and GPA unlock better scholarship offers. Choose wisely - this will be your home for the next four years!
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
