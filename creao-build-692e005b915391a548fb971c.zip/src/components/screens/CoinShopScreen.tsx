// Coin Shop screen for purchasing in-game coins with real money

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { type GameState } from '@/types/game';
import { DollarSign, Coins, Sparkles, Crown, Gem } from 'lucide-react';

interface CoinShopScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

interface CoinPackage {
  id: string;
  name: string;
  coins: number;
  price: number;
  bonus: number;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  popular?: boolean;
  bestValue?: boolean;
}

const COIN_PACKAGES: CoinPackage[] = [
  {
    id: 'starter',
    name: 'Starter Pack',
    coins: 100,
    price: 0.99,
    bonus: 0,
    icon: Coins,
    color: 'from-slate-500 to-slate-600',
  },
  {
    id: 'bronze',
    name: 'Bronze Pack',
    coins: 500,
    price: 3.99,
    bonus: 50,
    icon: Sparkles,
    color: 'from-orange-600 to-orange-700',
    popular: true,
  },
  {
    id: 'silver',
    name: 'Silver Pack',
    coins: 1200,
    price: 7.99,
    bonus: 200,
    icon: Gem,
    color: 'from-blue-500 to-blue-600',
  },
  {
    id: 'gold',
    name: 'Gold Pack',
    coins: 2500,
    price: 14.99,
    bonus: 500,
    icon: Crown,
    color: 'from-yellow-500 to-yellow-600',
    bestValue: true,
  },
  {
    id: 'platinum',
    name: 'Platinum Pack',
    coins: 5500,
    price: 29.99,
    bonus: 1500,
    icon: Crown,
    color: 'from-purple-500 to-purple-600',
  },
];

export const CoinShopScreen = ({ gameState, updateGameState }: CoinShopScreenProps) => {
  const [processing, setProcessing] = useState(false);
  const [purchaseSuccess, setPurchaseSuccess] = useState<string | null>(null);

  const handlePurchase = (pkg: CoinPackage) => {
    // Mock payment processing
    setProcessing(true);
    setPurchaseSuccess(null);

    // Simulate payment processing delay
    setTimeout(() => {
      const totalCoins = pkg.coins + pkg.bonus;

      // Update game state with new coins
      updateGameState({
        currency: {
          ...gameState.currency,
          coins: gameState.currency.coins + totalCoins,
        },
      });

      setProcessing(false);
      setPurchaseSuccess(pkg.id);

      // Clear success message after 3 seconds
      setTimeout(() => {
        setPurchaseSuccess(null);
      }, 3000);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-yellow-600 to-orange-600 border-2 border-yellow-500">
        <CardHeader>
          <CardTitle className="text-white text-2xl flex items-center gap-2">
            <DollarSign className="w-6 h-6" />
            Coin Shop
          </CardTitle>
          <CardDescription className="text-yellow-100 text-base">
            Purchase coins to unlock premium items and boost your career!
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="text-white">
                <div className="text-sm font-semibold">Your Balance</div>
                <div className="text-3xl font-bold flex items-center gap-2">
                  <Coins className="w-8 h-8 text-yellow-300" />
                  {gameState.currency.coins}
                </div>
              </div>
              <div className="text-yellow-100 text-sm bg-white/10 px-4 py-2 rounded">
                All purchases are simulated for demo purposes
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {purchaseSuccess && (
        <Card className="bg-green-600 border-2 border-green-500 animate-in fade-in slide-in-from-top-5">
          <CardContent className="pt-6">
            <div className="text-center text-white">
              <div className="text-2xl font-bold mb-2">Purchase Successful!</div>
              <div className="text-green-100">Coins have been added to your account</div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {COIN_PACKAGES.map((pkg) => {
          const Icon = pkg.icon;
          const isSuccess = purchaseSuccess === pkg.id;

          return (
            <Card
              key={pkg.id}
              className={`relative bg-white dark:bg-slate-800 border-2 transition-all ${
                isSuccess
                  ? 'border-green-500 shadow-green-500/50 shadow-xl'
                  : 'border-slate-300 dark:border-slate-600 hover:shadow-xl'
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-red-500 text-white font-bold">POPULAR</Badge>
                </div>
              )}
              {pkg.bestValue && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-green-500 text-white font-bold">BEST VALUE</Badge>
                </div>
              )}

              <CardHeader className={`bg-gradient-to-br ${pkg.color} text-white`}>
                <div className="flex items-center justify-center mb-2">
                  <Icon className="w-12 h-12" />
                </div>
                <CardTitle className="text-center text-white text-xl">
                  {pkg.name}
                </CardTitle>
                <CardDescription className="text-center text-white/90 font-semibold text-lg">
                  ${pkg.price.toFixed(2)}
                </CardDescription>
              </CardHeader>

              <CardContent className="pt-6 space-y-4">
                <div className="text-center">
                  <div className="text-4xl font-bold text-slate-900 dark:text-white flex items-center justify-center gap-2">
                    <Coins className="w-8 h-8 text-yellow-500" />
                    {pkg.coins.toLocaleString()}
                  </div>
                  {pkg.bonus > 0 && (
                    <div className="mt-2 text-green-600 dark:text-green-400 font-semibold">
                      +{pkg.bonus} BONUS COINS!
                    </div>
                  )}
                  {pkg.bonus > 0 && (
                    <div className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                      Total: {(pkg.coins + pkg.bonus).toLocaleString()} coins
                    </div>
                  )}
                </div>

                <Button
                  onClick={() => handlePurchase(pkg)}
                  disabled={processing}
                  className={`w-full h-12 font-bold text-lg bg-gradient-to-r ${pkg.color} hover:opacity-90 text-white`}
                >
                  {processing && purchaseSuccess === null ? (
                    'Processing...'
                  ) : isSuccess ? (
                    '✓ Purchased!'
                  ) : (
                    `Buy for $${pkg.price.toFixed(2)}`
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-slate-100 dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600">
        <CardHeader>
          <CardTitle className="text-lg">Why Purchase Coins?</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-slate-700 dark:text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-green-500 font-bold">✓</span>
              <span>Buy premium gear and equipment from the shop</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 font-bold">✓</span>
              <span>Purchase energy refills to train and play more</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 font-bold">✓</span>
              <span>Unlock special character customization options</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 font-bold">✓</span>
              <span>Speed up your progression and dominate the field!</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};
