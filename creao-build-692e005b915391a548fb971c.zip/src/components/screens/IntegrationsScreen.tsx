// Integrations Screen - Social Media, Streaming, Brand Partnerships, and Media

import { useState } from 'react';
import { type GameState, type SocialMediaIntegration, type StreamingIntegration, type BrandPartnership, type MediaAppearance } from '@/types/game';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Share2, Video, Handshake, Mic, TrendingUp, Users,
  DollarSign, CheckCircle, Lock, Unlock, Star, Zap
} from 'lucide-react';
import { toast } from 'sonner';

interface IntegrationsScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

export const IntegrationsScreen = ({ gameState, updateGameState }: IntegrationsScreenProps) => {
  const [selectedTab, setSelectedTab] = useState<'social' | 'streaming' | 'brands' | 'media'>('social');

  // Initialize integrations if not present
  const initializeSocialMedia = (): SocialMediaIntegration[] => {
    if (gameState.socialMedia.length > 0) return gameState.socialMedia;

    return [
      { id: 'twitter', platform: 'Twitter', followers: 0, engagement: 0, postsThisWeek: 0, verified: false, unlocked: false, unlockCost: 0 },
      { id: 'instagram', platform: 'Instagram', followers: 0, engagement: 0, postsThisWeek: 0, verified: false, unlocked: false, unlockCost: 500 },
      { id: 'tiktok', platform: 'TikTok', followers: 0, engagement: 0, postsThisWeek: 0, verified: false, unlocked: false, unlockCost: 750 },
      { id: 'youtube', platform: 'YouTube', followers: 0, engagement: 0, postsThisWeek: 0, verified: false, unlocked: false, unlockCost: 1000 },
    ];
  };

  const initializeStreaming = (): StreamingIntegration[] => {
    if (gameState.streaming.length > 0) return gameState.streaming;

    return [
      { id: 'twitch', platform: 'Twitch', subscribers: 0, avgViewers: 0, hoursStreamed: 0, unlocked: false, unlockCost: 1500 },
      { id: 'youtube-gaming', platform: 'YouTube Gaming', subscribers: 0, avgViewers: 0, hoursStreamed: 0, unlocked: false, unlockCost: 1500 },
      { id: 'kick', platform: 'Kick', subscribers: 0, avgViewers: 0, hoursStreamed: 0, unlocked: false, unlockCost: 1200 },
    ];
  };

  const initializeBrandPartnerships = (): BrandPartnership[] => {
    if (gameState.brandPartnerships.length > 0) return gameState.brandPartnerships;

    return [
      { id: 'nike-bronze', brand: 'Nike', category: 'Apparel', tier: 'bronze', weeklyPay: 500, bonusPerPost: 50, requiresFollowers: 5000, requiresEngagement: 25, active: false },
      { id: 'adidas-bronze', brand: 'Adidas', category: 'Apparel', tier: 'bronze', weeklyPay: 500, bonusPerPost: 50, requiresFollowers: 5000, requiresEngagement: 25, active: false },
      { id: 'gfuel-bronze', brand: 'G FUEL', category: 'Energy', tier: 'bronze', weeklyPay: 300, bonusPerPost: 40, requiresFollowers: 3000, requiresEngagement: 20, active: false },
      { id: 'razer-silver', brand: 'Razer', category: 'Gaming', tier: 'silver', weeklyPay: 1000, bonusPerPost: 100, requiresFollowers: 15000, requiresEngagement: 40, active: false },
      { id: 'apple-gold', brand: 'Apple', category: 'Tech', tier: 'gold', weeklyPay: 2500, bonusPerPost: 250, requiresFollowers: 50000, requiresEngagement: 60, active: false },
    ];
  };

  const initializeMediaAppearances = (): MediaAppearance[] => {
    if (gameState.mediaAppearances.length > 0) return gameState.mediaAppearances;

    return [
      { id: 'podcast-1', type: 'Podcast', title: 'The Soccer Life Podcast', reputationBonus: 50, followerBonus: 500, payAmount: 200, completed: false, availableAtWeek: 5 },
      { id: 'interview-1', type: 'Interview', title: 'Local Sports News Interview', reputationBonus: 100, followerBonus: 1000, payAmount: 500, completed: false, availableAtWeek: 10 },
      { id: 'magazine-1', type: 'Magazine', title: 'College Soccer Magazine Feature', reputationBonus: 200, followerBonus: 2500, payAmount: 1000, completed: false, availableAtWeek: 15 },
      { id: 'documentary-1', type: 'Documentary', title: 'Rising Stars Documentary', reputationBonus: 500, followerBonus: 10000, payAmount: 5000, completed: false, availableAtWeek: 25 },
    ];
  };

  const socialMedia = initializeSocialMedia();
  const streaming = initializeStreaming();
  const brandPartnerships = initializeBrandPartnerships();
  const mediaAppearances = initializeMediaAppearances();

  const totalFollowers = socialMedia.reduce((sum, sm) => sum + sm.followers, 0);
  const avgEngagement = socialMedia.length > 0
    ? Math.floor(socialMedia.reduce((sum, sm) => sum + sm.engagement, 0) / socialMedia.filter(sm => sm.unlocked).length || 1)
    : 0;

  const unlockPlatform = (platformId: string, cost: number, type: 'social' | 'streaming') => {
    if (gameState.currency.coins < cost) {
      toast.error('Not enough coins!');
      return;
    }

    if (type === 'social') {
      const updated = socialMedia.map(sm =>
        sm.id === platformId ? { ...sm, unlocked: true } : sm
      );
      updateGameState({
        socialMedia: updated,
        currency: { ...gameState.currency, coins: gameState.currency.coins - cost }
      });
      toast.success(`Unlocked ${updated.find(sm => sm.id === platformId)?.platform}!`);
    } else {
      const updated = streaming.map(st =>
        st.id === platformId ? { ...st, unlocked: true } : st
      );
      updateGameState({
        streaming: updated,
        currency: { ...gameState.currency, coins: gameState.currency.coins - cost }
      });
      toast.success(`Unlocked ${updated.find(st => st.id === platformId)?.platform}!`);
    }
  };

  const createPost = (platform: SocialMediaIntegration) => {
    if (gameState.energy < 10) {
      toast.error('Not enough energy! Need 10 energy to create a post.');
      return;
    }

    if (platform.postsThisWeek >= 5) {
      toast.error('You\'ve reached the weekly post limit for this platform!');
      return;
    }

    const followerGain = Math.floor((50 + gameState.contentCreationSkill * 10) * (1 + gameState.reputation / 1000));
    const engagementGain = Math.min(100, platform.engagement + Math.floor(5 + gameState.contentCreationSkill));

    const updated = socialMedia.map(sm =>
      sm.id === platform.id
        ? {
            ...sm,
            followers: sm.followers + followerGain,
            engagement: engagementGain,
            postsThisWeek: sm.postsThisWeek + 1
          }
        : sm
    );

    // Check for brand partnership bonuses
    const activeBrands = brandPartnerships.filter(bp => bp.active);
    let bonusEarnings = 0;
    activeBrands.forEach(brand => {
      bonusEarnings += brand.bonusPerPost;
    });

    updateGameState({
      socialMedia: updated,
      energy: gameState.energy - 10,
      contentCreationSkill: Math.min(100, gameState.contentCreationSkill + 1),
      currency: {
        ...gameState.currency,
        nilMoney: gameState.currency.nilMoney + bonusEarnings
      }
    });

    toast.success(`Posted! +${followerGain} followers${bonusEarnings > 0 ? `, +$${bonusEarnings} from brands` : ''}`);
  };

  const goLive = (platform: StreamingIntegration) => {
    if (gameState.energy < 25) {
      toast.error('Not enough energy! Streaming requires 25 energy.');
      return;
    }

    const viewerGain = Math.floor((10 + gameState.contentCreationSkill * 2) * (1 + gameState.reputation / 500));
    const subGain = Math.floor(viewerGain / 20);

    const updated = streaming.map(st =>
      st.id === platform.id
        ? {
            ...st,
            avgViewers: st.avgViewers + viewerGain,
            subscribers: st.subscribers + subGain,
            hoursStreamed: st.hoursStreamed + 2
          }
        : st
    );

    const earnings = Math.floor(viewerGain * 2 + subGain * 5);

    updateGameState({
      streaming: updated,
      energy: gameState.energy - 25,
      contentCreationSkill: Math.min(100, gameState.contentCreationSkill + 2),
      currency: {
        ...gameState.currency,
        nilMoney: gameState.currency.nilMoney + earnings
      }
    });

    toast.success(`Stream complete! +${viewerGain} avg viewers, +${subGain} subs, +$${earnings}`);
  };

  const activateBrand = (brand: BrandPartnership) => {
    if (totalFollowers < brand.requiresFollowers) {
      toast.error(`Need ${brand.requiresFollowers.toLocaleString()} followers!`);
      return;
    }
    if (avgEngagement < brand.requiresEngagement) {
      toast.error(`Need ${brand.requiresEngagement}% average engagement!`);
      return;
    }

    const activeBrandsCount = brandPartnerships.filter(bp => bp.active).length;
    if (activeBrandsCount >= 3) {
      toast.error('Maximum 3 active brand partnerships!');
      return;
    }

    const updated = brandPartnerships.map(bp =>
      bp.id === brand.id ? { ...bp, active: true, weeksRemaining: 12 } : bp
    );

    updateGameState({
      brandPartnerships: updated,
    });

    toast.success(`Partnered with ${brand.brand}! +$${brand.weeklyPay}/week`);
  };

  const completeMedia = (media: MediaAppearance) => {
    if (gameState.week < media.availableAtWeek) {
      toast.error(`Available at week ${media.availableAtWeek}!`);
      return;
    }

    if (gameState.energy < 20) {
      toast.error('Not enough energy! Media appearances require 20 energy.');
      return;
    }

    const updated = mediaAppearances.map(ma =>
      ma.id === media.id ? { ...ma, completed: true } : ma
    );

    // Add followers to the primary platform (Twitter by default)
    const updatedSocial = socialMedia.map(sm =>
      sm.id === 'twitter' && sm.unlocked
        ? { ...sm, followers: sm.followers + media.followerBonus }
        : sm
    );

    updateGameState({
      mediaAppearances: updated,
      socialMedia: updatedSocial,
      reputation: gameState.reputation + media.reputationBonus,
      energy: gameState.energy - 20,
      currency: {
        ...gameState.currency,
        nilMoney: gameState.currency.nilMoney + media.payAmount
      }
    });

    toast.success(`${media.type} complete! +${media.reputationBonus} rep, +${media.followerBonus} followers, +$${media.payAmount}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Integrations & Brand Deals</h1>
          <p className="text-slate-300">Build your personal brand and earn NIL money</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-slate-400">Total Followers</div>
          <div className="text-2xl font-bold text-white">{totalFollowers.toLocaleString()}</div>
          <div className="text-sm text-slate-400">Content Skill: {gameState.contentCreationSkill}/100</div>
        </div>
      </div>

      <Tabs value={selectedTab} onValueChange={(v) => setSelectedTab(v as typeof selectedTab)}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="social" className="flex items-center gap-2">
            <Share2 className="w-4 h-4" />
            Social Media
          </TabsTrigger>
          <TabsTrigger value="streaming" className="flex items-center gap-2">
            <Video className="w-4 h-4" />
            Streaming
          </TabsTrigger>
          <TabsTrigger value="brands" className="flex items-center gap-2">
            <Handshake className="w-4 h-4" />
            Brand Deals
          </TabsTrigger>
          <TabsTrigger value="media" className="flex items-center gap-2">
            <Mic className="w-4 h-4" />
            Media
          </TabsTrigger>
        </TabsList>

        <TabsContent value="social" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Share2 className="w-5 h-5" />
                Social Media Platforms
              </CardTitle>
              <CardDescription>
                Grow your following and engage with fans. Posts cost 10 energy. Max 5 posts per platform per week.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {socialMedia.map(platform => (
                <Card key={platform.id} className={!platform.unlocked ? 'opacity-60' : ''}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-lg font-bold">{platform.platform}</h3>
                          {platform.verified && <Badge variant="default" className="bg-blue-500">Verified</Badge>}
                          {!platform.unlocked && <Lock className="w-4 h-4 text-slate-400" />}
                        </div>
                        {platform.unlocked && (
                          <div className="grid grid-cols-3 gap-2 text-sm">
                            <div>
                              <div className="text-slate-500">Followers</div>
                              <div className="font-bold">{platform.followers.toLocaleString()}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Engagement</div>
                              <div className="font-bold">{platform.engagement}%</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Posts This Week</div>
                              <div className="font-bold">{platform.postsThisWeek}/5</div>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        {!platform.unlocked ? (
                          <Button
                            onClick={() => unlockPlatform(platform.id, platform.unlockCost, 'social')}
                            variant="default"
                            size="sm"
                          >
                            <Unlock className="w-4 h-4 mr-1" />
                            Unlock ({platform.unlockCost} coins)
                          </Button>
                        ) : (
                          <Button
                            onClick={() => createPost(platform)}
                            disabled={gameState.energy < 10 || platform.postsThisWeek >= 5}
                            size="sm"
                          >
                            <Zap className="w-4 h-4 mr-1" />
                            Create Post (10 energy)
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="streaming" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="w-5 h-5" />
                Streaming Platforms
              </CardTitle>
              <CardDescription>
                Stream gameplay and interact with viewers. Each stream costs 25 energy and lasts 2 hours.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {streaming.map(platform => (
                <Card key={platform.id} className={!platform.unlocked ? 'opacity-60' : ''}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-lg font-bold">{platform.platform}</h3>
                          {!platform.unlocked && <Lock className="w-4 h-4 text-slate-400" />}
                        </div>
                        {platform.unlocked && (
                          <div className="grid grid-cols-3 gap-2 text-sm">
                            <div>
                              <div className="text-slate-500">Subscribers</div>
                              <div className="font-bold">{platform.subscribers.toLocaleString()}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Avg Viewers</div>
                              <div className="font-bold">{platform.avgViewers.toLocaleString()}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Hours Streamed</div>
                              <div className="font-bold">{platform.hoursStreamed}</div>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        {!platform.unlocked ? (
                          <Button
                            onClick={() => unlockPlatform(platform.id, platform.unlockCost, 'streaming')}
                            variant="default"
                            size="sm"
                          >
                            <Unlock className="w-4 h-4 mr-1" />
                            Unlock ({platform.unlockCost} coins)
                          </Button>
                        ) : (
                          <Button
                            onClick={() => goLive(platform)}
                            disabled={gameState.energy < 25}
                            size="sm"
                          >
                            <Video className="w-4 h-4 mr-1" />
                            Go Live (25 energy)
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="brands" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Handshake className="w-5 h-5" />
                Brand Partnerships
              </CardTitle>
              <CardDescription>
                Partner with brands for weekly NIL payments and post bonuses. Maximum 3 active partnerships.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="flex items-center gap-2 text-sm">
                  <Users className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span className="font-semibold text-blue-900 dark:text-blue-100">
                    Current Stats: {totalFollowers.toLocaleString()} followers, {avgEngagement}% avg engagement
                  </span>
                </div>
              </div>

              {brandPartnerships.map(brand => {
                const canActivate = totalFollowers >= brand.requiresFollowers && avgEngagement >= brand.requiresEngagement;

                return (
                  <Card key={brand.id} className={brand.active ? 'border-green-500 border-2' : canActivate ? '' : 'opacity-60'}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="text-lg font-bold">{brand.brand}</h3>
                            <Badge variant={
                              brand.tier === 'bronze' ? 'secondary' :
                              brand.tier === 'silver' ? 'default' :
                              brand.tier === 'gold' ? 'default' : 'default'
                            } className={
                              brand.tier === 'gold' ? 'bg-yellow-500' :
                              brand.tier === 'silver' ? 'bg-slate-400' :
                              brand.tier === 'platinum' ? 'bg-purple-500' : ''
                            }>
                              {brand.tier.toUpperCase()}
                            </Badge>
                            <Badge variant="outline">{brand.category}</Badge>
                            {brand.active && <CheckCircle className="w-5 h-5 text-green-500" />}
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-sm mb-2">
                            <div>
                              <div className="text-slate-500">Weekly Pay</div>
                              <div className="font-bold text-green-600">${brand.weeklyPay}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Bonus Per Post</div>
                              <div className="font-bold text-green-600">${brand.bonusPerPost}</div>
                            </div>
                          </div>
                          <div className="text-xs text-slate-500">
                            Requires: {brand.requiresFollowers.toLocaleString()} followers, {brand.requiresEngagement}% engagement
                          </div>
                          {brand.active && brand.weeksRemaining && (
                            <div className="text-xs text-blue-600 font-semibold mt-1">
                              {brand.weeksRemaining} weeks remaining
                            </div>
                          )}
                        </div>
                        {!brand.active && (
                          <Button
                            onClick={() => activateBrand(brand)}
                            disabled={!canActivate}
                            size="sm"
                          >
                            <Star className="w-4 h-4 mr-1" />
                            Activate
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="media" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mic className="w-5 h-5" />
                Media Appearances
              </CardTitle>
              <CardDescription>
                Accept interviews, podcasts, and media opportunities. Costs 20 energy each.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {mediaAppearances.map(media => {
                const isAvailable = gameState.week >= media.availableAtWeek;

                return (
                  <Card key={media.id} className={media.completed ? 'opacity-60' : !isAvailable ? 'opacity-40' : ''}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-bold">{media.title}</h3>
                            <Badge variant="outline">{media.type}</Badge>
                            {media.completed && <CheckCircle className="w-5 h-5 text-green-500" />}
                          </div>
                          <div className="grid grid-cols-3 gap-2 text-sm mb-2">
                            <div>
                              <div className="text-slate-500">Reputation</div>
                              <div className="font-bold text-purple-600">+{media.reputationBonus}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Followers</div>
                              <div className="font-bold text-blue-600">+{media.followerBonus.toLocaleString()}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Payment</div>
                              <div className="font-bold text-green-600">${media.payAmount}</div>
                            </div>
                          </div>
                          {!isAvailable && (
                            <div className="text-xs text-yellow-600 font-semibold">
                              Available at week {media.availableAtWeek}
                            </div>
                          )}
                        </div>
                        {!media.completed && isAvailable && (
                          <Button
                            onClick={() => completeMedia(media)}
                            disabled={gameState.energy < 20}
                            size="sm"
                          >
                            <Mic className="w-4 h-4 mr-1" />
                            Accept (20 energy)
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
