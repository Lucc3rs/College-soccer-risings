// Stats and progression screen

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { type GameState, type PlayerStats } from '@/types/game';
import { TrendingUp } from 'lucide-react';

interface StatsScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

export const StatsScreen = ({ gameState, updateGameState }: StatsScreenProps) => {
  const stats: { name: string; key: keyof PlayerStats; color: string }[] = [
    { name: 'Pace', key: 'pace', color: 'bg-blue-500' },
    { name: 'Shooting', key: 'shooting', color: 'bg-red-500' },
    { name: 'Passing', key: 'passing', color: 'bg-green-500' },
    { name: 'Dribbling', key: 'dribbling', color: 'bg-purple-500' },
    { name: 'Strength', key: 'strength', color: 'bg-orange-500' },
    { name: 'Stamina', key: 'stamina', color: 'bg-yellow-500' },
    { name: 'Defending', key: 'defending', color: 'bg-indigo-500' },
    { name: 'Confidence', key: 'confidence', color: 'bg-pink-500' },
    { name: 'Leadership', key: 'leadership', color: 'bg-cyan-500' },
  ];

  const improveStat = (stat: keyof PlayerStats) => {
    if (gameState.skillPoints <= 0) return;

    updateGameState({
      stats: {
        ...gameState.stats,
        [stat]: Math.min(99, gameState.stats[stat] + 1),
      },
      skillPoints: gameState.skillPoints - 1,
    });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Player Stats</CardTitle>
          <CardDescription>
            Skill Points Available: {gameState.skillPoints}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {stats.map((stat) => (
            <div key={stat.key} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">{stat.name}</span>
                <div className="flex items-center gap-3">
                  <span className="font-bold">{gameState.stats[stat.key]}/99</span>
                  <Button
                    size="sm"
                    onClick={() => improveStat(stat.key)}
                    disabled={gameState.skillPoints <= 0 || gameState.stats[stat.key] >= 99}
                  >
                    <TrendingUp className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <Progress value={gameState.stats[stat.key]} />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Progression</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm text-slate-500">Level</div>
              <div className="text-3xl font-bold">{gameState.level}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">XP Progress</div>
              <div className="text-xl font-bold">{gameState.xp} / {gameState.xpToNextLevel}</div>
            </div>
          </div>
          <Progress value={(gameState.xp / gameState.xpToNextLevel) * 100} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Unlocked Traits</CardTitle>
        </CardHeader>
        <CardContent>
          {gameState.unlockedTraits.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {gameState.unlockedTraits.map((trait) => (
                <span key={trait} className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">
                  {trait}
                </span>
              ))}
            </div>
          ) : (
            <p className="text-slate-500">No traits unlocked yet. Keep leveling up!</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
