// Scholarship management screen

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { type GameState } from '@/types/game';
import { generateScholarshipOffers } from '@/lib/game-data';
import { GraduationCap, CheckCircle } from 'lucide-react';

interface ScholarshipScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

export const ScholarshipScreen = ({ gameState, updateGameState }: ScholarshipScreenProps) => {
  const checkOffers = () => {
    const offers = generateScholarshipOffers(gameState.profile.college, gameState.reputation);
    updateGameState({
      scholarshipOffers: offers,
    });
  };

  const acceptOffer = (offerId: string) => {
    const offer = gameState.scholarshipOffers.find(o => o.id === offerId);
    if (!offer) return;

    updateGameState({
      currentScholarship: offer.tier,
      scholarshipOffers: [],
    });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Current Scholarship</CardTitle>
          <CardDescription>Your scholarship status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <GraduationCap className="w-12 h-12 text-blue-600" />
            <div>
              <div className="text-2xl font-bold capitalize">{gameState.currentScholarship} Scholarship</div>
              <div className="text-slate-500">
                {gameState.currentScholarship === 'none' && 'Walk-on player'}
                {gameState.currentScholarship === 'partial' && '$25,000/year covered'}
                {gameState.currentScholarship === 'full' && '$50,000/year fully covered'}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Eligibility</CardTitle>
          <CardDescription>Requirements for scholarship upgrades</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <span>GPA Requirement (3.0+)</span>
            <Badge variant={gameState.gpa >= 3.0 ? 'default' : 'destructive'}>
              {gameState.gpa.toFixed(2)}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span>Reputation</span>
            <Badge variant={gameState.reputation >= 50 ? 'default' : 'secondary'}>
              {gameState.reputation}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span>Overall Rating</span>
            <Badge variant="outline">
              {Math.floor(Object.values(gameState.stats).reduce((a, b) => a + b, 0) / 9)}
            </Badge>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Available Offers</CardTitle>
          <CardDescription>
            Scholarship opportunities based on your performance
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {gameState.scholarshipOffers.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-500 mb-4">Check for new scholarship offers</p>
              <Button onClick={checkOffers}>
                Check for Offers
              </Button>
            </div>
          ) : (
            gameState.scholarshipOffers.map((offer) => (
              <div key={offer.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-lg">{offer.college}</h3>
                    <p className="text-sm text-slate-500 capitalize">{offer.tier} Scholarship</p>
                  </div>
                  <Badge variant="default" className="text-lg">
                    ${(offer.value / 1000).toFixed(0)}k/year
                  </Badge>
                </div>
                <div className="mb-3">
                  <p className="text-sm font-semibold mb-1">Requirements:</p>
                  <ul className="text-sm space-y-1">
                    {offer.requirements.map((req, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>
                <Button onClick={() => acceptOffer(offer.id)} className="w-full">
                  Accept Offer
                </Button>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
};
