// Schedule screen with weekly activities and matches

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { type GameState, type MatchResult } from '@/types/game';
import { simulateMatch, advanceWeek, ENERGY_COSTS } from '@/lib/game-engine';
import { STORY_CHOICES } from '@/lib/game-data';
import { Trophy, GraduationCap, Calendar, ArrowRight } from 'lucide-react';

interface ScheduleScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

export const ScheduleScreen = ({ gameState, updateGameState }: ScheduleScreenProps) => {
  const [matchInProgress, setMatchInProgress] = useState(false);
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null);
  const [storyChoice, setStoryChoice] = useState<typeof STORY_CHOICES[0] | null>(null);
  const [matchMoment, setMatchMoment] = useState<number>(0);
  const [totalMoments, setTotalMoments] = useState<number>(3);
  const [matchScore, setMatchScore] = useState({ player: 0, opponent: 0 });
  const [performanceBonus, setPerformanceBonus] = useState(0);
  const [currentMatchTime, setCurrentMatchTime] = useState<number>(0);
  const [nextMomentTime, setNextMomentTime] = useState<number>(0);
  const [isClockRunning, setIsClockRunning] = useState(false);
  const [buttonsEnabled, setButtonsEnabled] = useState(false);

  // Clock cycling effect - updates every 200ms to simulate smooth clock progression
  useEffect(() => {
    if (isClockRunning && matchInProgress && currentMatchTime < nextMomentTime) {
      const interval = setInterval(() => {
        setCurrentMatchTime(prev => {
          if (prev >= nextMomentTime - 1) {
            setIsClockRunning(false);
            // Enable buttons when clock reaches the moment time
            setButtonsEnabled(true);
            return nextMomentTime;
          }
          return prev + 1;
        });
      }, 200); // Update every 200ms for smooth progression

      return () => clearInterval(interval);
    }
  }, [isClockRunning, matchInProgress, currentMatchTime, nextMomentTime]);

  const attendClasses = () => {
    if (gameState.energy < ENERGY_COSTS.classes) {
      alert('Not enough energy!');
      return;
    }

    const gpaChange = (Math.random() * 0.3 - 0.05);
    updateGameState({
      gpa: Math.min(4.0, Math.max(0, gameState.gpa + gpaChange)),
      energy: gameState.energy - ENERGY_COSTS.classes,
      weeklyActivitiesDone: { ...gameState.weeklyActivitiesDone, classes: true },
      currency: {
        ...gameState.currency,
        coins: gameState.currency.coins + 25,
      },
    });
  };

  const playMatch = () => {
    if (gameState.energy < ENERGY_COSTS.match) {
      alert('Not enough energy!');
      return;
    }

    // Get current week's match from schedule (with safety check for backward compatibility)
    const currentMatch = gameState.seasonSchedule?.find(m => m.week === gameState.week && !m.completed);

    if (!currentMatch) {
      alert('No match scheduled for this week!');
      return;
    }

    const opponentDifficulty = currentMatch.opponentDifficulty;

    // Calculate number of moments based on difficulty
    // Easy opponents (difficulty < 60): 2-3 moments
    // Medium opponents (60-75): 3-4 moments
    // Hard opponents (75+): 4-6 moments
    let moments = 3;
    if (opponentDifficulty < 60) {
      moments = Math.floor(Math.random() * 2) + 2; // 2-3 moments
    } else if (opponentDifficulty < 75) {
      moments = Math.floor(Math.random() * 2) + 3; // 3-4 moments
    } else {
      moments = Math.floor(Math.random() * 3) + 4; // 4-6 moments
    }

    // Generate random time for first moment (between 10-30 minutes into the match)
    const firstMomentTime = Math.floor(Math.random() * 20) + 10;

    setMatchInProgress(true);
    setMatchMoment(1);
    setTotalMoments(moments);
    setMatchScore({ player: 0, opponent: 0 });
    setPerformanceBonus(0);
    setCurrentMatchTime(0);
    setNextMomentTime(firstMomentTime);
    setButtonsEnabled(false); // Disable buttons initially
    setIsClockRunning(true); // Start the clock
  };

  const handleMatchChoice = (choice: 'aggressive' | 'balanced' | 'defensive') => {
    // Disable buttons immediately after choice
    setButtonsEnabled(false);

    // Get current week's match from schedule (with safety check for backward compatibility)
    const currentMatch = gameState.seasonSchedule?.find(m => m.week === gameState.week && !m.completed);
    const opponentDifficulty = currentMatch ? currentMatch.opponentDifficulty : 50 + gameState.level * 2 + gameState.week;
    let bonus = 0;
    let scoreChange = { player: 0, opponent: 0 };

    // Calculate success based on player stats and choice
    const randomFactor = Math.random() * 100;
    const relevantStat = choice === 'aggressive' ? gameState.stats.shooting :
                        choice === 'balanced' ? gameState.stats.passing :
                        gameState.stats.defending;

    if (randomFactor < relevantStat) {
      // Success!
      bonus = choice === 'aggressive' ? 20 : choice === 'balanced' ? 10 : 5;
      if (matchMoment % 2 === 1) {
        scoreChange.player = 1;
      }
    } else {
      // Opponent's turn
      if (randomFactor > opponentDifficulty && matchMoment % 2 === 0) {
        scoreChange.opponent = 1;
      }
    }

    setMatchScore(prev => ({
      player: prev.player + scoreChange.player,
      opponent: prev.opponent + scoreChange.opponent
    }));
    setPerformanceBonus(prev => prev + bonus);

    if (matchMoment >= totalMoments) {
      // Match complete - wait for clock to finish before showing result
      setCurrentMatchTime(90); // Set to final whistle
      setIsClockRunning(false);
      // Delay showing the result by 2 seconds to let the game time finish
      setTimeout(() => {
        completeMatch();
      }, 2000);
    } else {
      setMatchMoment(prev => prev + 1);
      // Calculate next random moment time
      const timeJump = Math.floor(Math.random() * 15) + 10; // 10-25 minutes between moments
      const nextTime = Math.min(90, nextMomentTime + timeJump);
      setNextMomentTime(nextTime);
      setIsClockRunning(true); // Start clock cycling to next moment
    }
  };

  const completeMatch = () => {
    // Get current week's match from schedule (with safety check for backward compatibility)
    const currentMatch = gameState.seasonSchedule?.find(m => m.week === gameState.week && !m.completed);

    if (!currentMatch) {
      return;
    }

    const opponentDifficulty = currentMatch.opponentDifficulty;
    const result = simulateMatch(gameState.stats, gameState.profile.position, opponentDifficulty);

    // Apply performance bonus from interactive choices
    const bonusPerformance = Math.min(100, result.performance + performanceBonus);
    const finalResult = {
      ...result,
      performance: bonusPerformance,
      won: matchScore.player > matchScore.opponent,
    };

    setMatchResult(finalResult);

    const newXP = gameState.xp + finalResult.xpEarned + performanceBonus;
    const newReputation = gameState.reputation + finalResult.reputationEarned;
    const newCoins = gameState.currency.coins + (finalResult.won ? 100 : 50);

    // Update the schedule with match result (with safety check for backward compatibility)
    const updatedSchedule = (gameState.seasonSchedule || []).map(match =>
      match.id === currentMatch.id
        ? { ...match, completed: true, result: finalResult, score: matchScore }
        : match
    );

    // Update win/loss/tie record for regular season
    const isTie = matchScore.player === matchScore.opponent;
    const newWins = finalResult.won && currentMatch.phase === 'Regular Season'
      ? gameState.regularSeasonWins + 1
      : gameState.regularSeasonWins;
    const newLosses = !finalResult.won && !isTie && currentMatch.phase === 'Regular Season'
      ? gameState.regularSeasonLosses + 1
      : gameState.regularSeasonLosses;
    const newTies = isTie && currentMatch.phase === 'Regular Season'
      ? gameState.regularSeasonTies + 1
      : gameState.regularSeasonTies;

    updateGameState({
      xp: newXP,
      reputation: newReputation,
      energy: gameState.energy - ENERGY_COSTS.match,
      weeklyActivitiesDone: { ...gameState.weeklyActivitiesDone, match: true },
      matchHistory: [...gameState.matchHistory, finalResult],
      seasonSchedule: updatedSchedule,
      regularSeasonWins: newWins,
      regularSeasonLosses: newLosses,
      regularSeasonTies: newTies,
      currency: {
        ...gameState.currency,
        coins: newCoins,
        reputationPoints: gameState.currency.reputationPoints + (finalResult.won ? 10 : 5),
      },
      coachTrust: Math.min(100, gameState.coachTrust + (finalResult.performance > 70 ? 5 : -2)),
      fanSupport: Math.min(100, gameState.fanSupport + (finalResult.won ? 5 : -2)),
      stats: {
        ...gameState.stats,
        confidence: Math.min(99, gameState.stats.confidence + (finalResult.won ? 2 : 0)),
      },
    });

    setMatchInProgress(false);
  };

  const advanceToNextWeek = () => {
    const updates = advanceWeek(gameState);

    // Check for story choices
    const choice = STORY_CHOICES.find(
      c => c.week === gameState.week + 1 && c.season === gameState.season
    );

    if (choice) {
      setStoryChoice(choice);
    }

    updateGameState(updates);
    setMatchResult(null);
  };

  const skipToNextWeek = () => {
    // Calculate penalties for skipping activities
    let gpaChange = 0;
    let reputationChange = 0;
    let coachTrustChange = 0;
    let fanSupportChange = 0;
    const penalties: string[] = [];

    if (!gameState.weeklyActivitiesDone.classes) {
      gpaChange = -0.15;
      reputationChange -= 5;
      penalties.push('Missed classes: GPA -0.15, Reputation -5');
    }

    if (!gameState.weeklyActivitiesDone.match && gameState.phase !== 'Off-Season') {
      reputationChange -= 10;
      coachTrustChange = -15;
      fanSupportChange = -10;
      penalties.push('Missed match: Reputation -10, Coach Trust -15, Fan Support -10');
    }

    const confirmMessage = `Skip to next week?\n\nYou'll lose out on unfinished activities:\n${penalties.join('\n')}\n\nAre you sure?`;

    if (penalties.length > 0 && !confirm(confirmMessage)) {
      return;
    }

    const updates = advanceWeek(gameState);

    // Apply penalties
    const newGPA = Math.max(0, Math.min(4.0, gameState.gpa + gpaChange));
    const newReputation = Math.max(0, gameState.reputation + reputationChange);
    const newCoachTrust = Math.max(0, Math.min(100, gameState.coachTrust + coachTrustChange));
    const newFanSupport = Math.max(0, Math.min(100, gameState.fanSupport + fanSupportChange));

    updateGameState({
      ...updates,
      gpa: newGPA,
      reputation: newReputation,
      coachTrust: newCoachTrust,
      fanSupport: newFanSupport,
    });

    setMatchResult(null);
  };

  const handleStoryChoice = (optionIndex: number) => {
    if (!storyChoice) return;

    const option = storyChoice.options[optionIndex];
    const updates: Partial<GameState> = {
      choiceHistory: [...gameState.choiceHistory, { choiceId: storyChoice.id, optionIndex }],
    };

    if (option.effects.gpa) {
      updates.gpa = Math.min(4.0, Math.max(0, gameState.gpa + option.effects.gpa));
    }
    if (option.effects.reputation) {
      updates.reputation = Math.max(0, gameState.reputation + option.effects.reputation);
    }
    if (option.effects.teamChemistry) {
      updates.teamChemistry = Math.min(100, Math.max(0, gameState.teamChemistry + option.effects.teamChemistry));
    }
    if (option.effects.coachTrust) {
      updates.coachTrust = Math.min(100, Math.max(0, gameState.coachTrust + option.effects.coachTrust));
    }
    if (option.effects.fanSupport) {
      updates.fanSupport = Math.min(100, Math.max(0, gameState.fanSupport + option.effects.fanSupport));
    }
    if (option.effects.energy) {
      updates.energy = Math.min(gameState.maxEnergy, Math.max(0, gameState.energy + option.effects.energy));
    }
    if (option.effects.confidence) {
      updates.stats = {
        ...gameState.stats,
        confidence: Math.min(99, Math.max(0, gameState.stats.confidence + option.effects.confidence)),
      };
    }

    updateGameState(updates);
    setStoryChoice(null);
  };

  if (storyChoice) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>{storyChoice.title}</CardTitle>
          <CardDescription>Week {storyChoice.week} Decision</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-lg">{storyChoice.description}</p>
          <div className="space-y-3">
            {storyChoice.options.map((option, index) => (
              <Button
                key={index}
                onClick={() => handleStoryChoice(index)}
                className="w-full h-auto p-4 text-left flex flex-col items-start"
                variant="outline"
              >
                <span className="font-semibold">{option.text}</span>
                <span className="text-xs text-slate-500 mt-1">
                  {Object.entries(option.effects).map(([key, value]) =>
                    `${key}: ${value > 0 ? '+' : ''}${value}`
                  ).join(', ')}
                </span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (matchInProgress || matchResult) {
    return (
      <Card className="max-w-2xl mx-auto bg-gradient-to-br from-green-900 to-emerald-900 border-4 border-green-600">
        <CardHeader className="bg-gradient-to-r from-green-700 to-emerald-700 text-white">
          <CardTitle className="text-white text-2xl">
            {matchInProgress ? 'Match in Progress' : 'Match Result'}
          </CardTitle>
          {matchInProgress && (
            <CardDescription className="text-green-100 text-lg">
              {currentMatchTime}' • Score: {matchScore.player} - {matchScore.opponent}
            </CardDescription>
          )}
        </CardHeader>
        <CardContent className="space-y-4 bg-gradient-to-br from-slate-800 to-slate-900 p-6">
          {matchInProgress && (
            <>
              <div className="text-center py-4 bg-white dark:bg-slate-700 rounded-lg shadow-lg">
                <div className="text-6xl mb-4">⚽</div>
                <div className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
                  {matchScore.player} - {matchScore.opponent}
                </div>
                <div className="text-sm text-slate-600 dark:text-slate-300">
                  Performance Bonus: +{performanceBonus}
                </div>
              </div>
              <div className="space-y-3">
                <p className="text-white text-center text-lg font-semibold bg-slate-700 p-3 rounded">
                  {buttonsEnabled ? 'Choose your strategy!' : 'Wait for the action...'}
                </p>
                <Button
                  onClick={() => handleMatchChoice('aggressive')}
                  disabled={!buttonsEnabled}
                  className="w-full h-20 text-lg bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700 text-white font-bold shadow-xl"
                >
                  🔥 Aggressive Attack
                  <span className="text-xs block mt-1">High risk, high reward (+20 bonus)</span>
                </Button>
                <Button
                  onClick={() => handleMatchChoice('balanced')}
                  disabled={!buttonsEnabled}
                  className="w-full h-20 text-lg bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700 text-white font-bold shadow-xl"
                >
                  ⚖️ Balanced Play
                  <span className="text-xs block mt-1">Steady approach (+10 bonus)</span>
                </Button>
                <Button
                  onClick={() => handleMatchChoice('defensive')}
                  disabled={!buttonsEnabled}
                  className="w-full h-20 text-lg bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white font-bold shadow-xl"
                >
                  🛡️ Defensive Control
                  <span className="text-xs block mt-1">Safe option (+5 bonus)</span>
                </Button>
              </div>
            </>
          )}
          {matchResult && (
            <>
              <div className="text-center bg-white dark:bg-slate-800 rounded-lg p-6 shadow-lg">
                <div className={`text-5xl font-bold mb-2 ${matchResult.won ? 'text-green-600' : matchScore.player === matchScore.opponent ? 'text-yellow-600' : 'text-red-600'}`}>
                  {matchResult.won ? 'VICTORY!' : matchScore.player === matchScore.opponent ? 'TIE!' : 'DEFEAT'}
                </div>
                <div className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
                  {matchScore.player} - {matchScore.opponent}
                </div>
                <div className="text-xl text-slate-700 dark:text-slate-300">
                  Performance: {matchResult.performance.toFixed(0)}/100
                </div>
              </div>
              <div className="space-y-2 bg-slate-700 p-4 rounded-lg">
                <div className="flex justify-between text-white">
                  <span>XP Earned:</span>
                  <span className="font-bold text-green-400">+{matchResult.xpEarned}</span>
                </div>
                <div className="flex justify-between text-white">
                  <span>Reputation:</span>
                  <span className="font-bold text-blue-400">+{matchResult.reputationEarned}</span>
                </div>
                <div className="flex justify-between text-white">
                  <span>Coins:</span>
                  <span className="font-bold text-yellow-400">+{matchResult.won ? 100 : 50}</span>
                </div>
                <div className="flex justify-between text-white">
                  <span>Performance Bonus:</span>
                  <span className="font-bold text-purple-400">+{performanceBonus}</span>
                </div>
              </div>
              <div className="border-t border-slate-600 pt-4">
                <h4 className="font-semibold mb-2 text-white">Match Highlights:</h4>
                <ul className="space-y-1">
                  {matchResult.highlights.map((highlight, i) => (
                    <li key={i} className="text-sm text-slate-300">• {highlight}</li>
                  ))}
                </ul>
              </div>
              <Button
                onClick={() => setMatchResult(null)}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold text-lg h-12"
              >
                Continue
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    );
  }

  const allActivitiesDone =
    gameState.weeklyActivitiesDone.training &&
    gameState.weeklyActivitiesDone.classes &&
    (gameState.weeklyActivitiesDone.match || gameState.phase === 'Off-Season');

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Week {gameState.week} Schedule</CardTitle>
          <CardDescription>{gameState.phase} • {gameState.season}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                <span className="font-semibold">Classes</span>
                {gameState.weeklyActivitiesDone.classes && <Badge variant="secondary">Done</Badge>}
              </div>
              <Button
                onClick={attendClasses}
                disabled={gameState.weeklyActivitiesDone.classes || gameState.energy < ENERGY_COSTS.classes}
                className="w-full"
              >
                Attend Classes (-{ENERGY_COSTS.classes} energy)
              </Button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5" />
                <span className="font-semibold">Match</span>
                {gameState.weeklyActivitiesDone.match && <Badge variant="secondary">Done</Badge>}
              </div>
              <Button
                onClick={playMatch}
                disabled={gameState.weeklyActivitiesDone.match || gameState.energy < ENERGY_COSTS.match || gameState.phase === 'Off-Season'}
                className="w-full"
              >
                {gameState.phase === 'Off-Season' ? 'Off-Season' : `Play Match (-${ENERGY_COSTS.match} energy)`}
              </Button>
            </div>
          </div>

          {allActivitiesDone && (
            <div className="mt-6 p-4 bg-green-50 dark:bg-green-900/20 rounded border border-green-200 dark:border-green-700">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold text-green-900 dark:text-green-100">Week Complete!</div>
                  <div className="text-sm text-green-700 dark:text-green-300">Advance to next week</div>
                </div>
                <Button onClick={advanceToNextWeek} className="bg-green-600 hover:bg-green-700">
                  Next Week <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {!allActivitiesDone && gameState.energy === 0 && (
            <div className="mt-6 p-4 bg-red-50 dark:bg-red-900/20 rounded border border-red-200 dark:border-red-700">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex-1">
                  <div className="font-semibold text-red-900 dark:text-red-100">Out of Energy!</div>
                  <div className="text-sm text-red-700 dark:text-red-300">
                    Skip to next week? Missing activities will have consequences.
                  </div>
                  {!gameState.weeklyActivitiesDone.classes && (
                    <div className="text-xs text-red-600 dark:text-red-400 mt-1">
                      ⚠️ Missing classes: -0.15 GPA, -5 Reputation
                    </div>
                  )}
                  {!gameState.weeklyActivitiesDone.match && gameState.phase !== 'Off-Season' && (
                    <div className="text-xs text-red-600 dark:text-red-400 mt-1">
                      ⚠️ Missing match: -10 Reputation, -15 Coach Trust, -10 Fan Support
                    </div>
                  )}
                </div>
                <Button onClick={skipToNextWeek} variant="destructive" className="bg-red-600 hover:bg-red-700">
                  Skip Week <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
