// NIL deals screen

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { type GameState, type NILDeal } from '@/types/game';
import { NIL_DEALS_POOL } from '@/lib/game-data';
import { isEligibleForNILDeal } from '@/lib/game-engine';
import { DollarSign, TrendingUp } from 'lucide-react';

interface NILScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

export const NILScreen = ({ gameState, updateGameState }: NILScreenProps) => {
  const checkDeals = () => {
    const available = NIL_DEALS_POOL.map((deal, i) => ({
      ...deal,
      id: `nil-${Date.now()}-${i}`,
    })).filter(deal => {
      const alreadySigned = gameState.activeNILDeals.some(active => active.brand === deal.brand);
      return !alreadySigned && isEligibleForNILDeal(gameState, deal);
    });

    updateGameState({
      availableNILDeals: available,
    });
  };

  const signDeal = (dealId: string) => {
    const deal = gameState.availableNILDeals.find(d => d.id === dealId);
    if (!deal) return;

    updateGameState({
      activeNILDeals: [...gameState.activeNILDeals, deal],
      availableNILDeals: gameState.availableNILDeals.filter(d => d.id !== dealId),
      achievements: gameState.achievements.map(a =>
        a.id === 'first-nil' ? { ...a, unlocked: true, progress: 1 } :
        a.id === 'platinum-nil' && deal.tier === 'platinum' ? { ...a, unlocked: true, progress: 1 } :
        a
      ),
    });
  };

  const totalWeeklyIncome = gameState.activeNILDeals.reduce((sum, deal) => sum + deal.weeklyPay, 0);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Active NIL Deals</CardTitle>
          <CardDescription>Your current sponsorships</CardDescription>
        </CardHeader>
        <CardContent>
          {gameState.activeNILDeals.length === 0 ? (
            <p className="text-slate-500 text-center py-4">No active NIL deals</p>
          ) : (
            <div className="space-y-3">
              {gameState.activeNILDeals.map((deal) => (
                <div key={deal.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-bold">{deal.brand}</h3>
                      <Badge variant="outline" className="mt-1 capitalize">
                        {deal.tier}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600">${deal.weeklyPay}/week</div>
                      <div className="text-sm text-slate-500">{deal.weeksRemaining} weeks left</div>
                    </div>
                  </div>
                  <Progress value={(deal.weeksRemaining / 12) * 100} className="mt-2" />
                </div>
              ))}
              <div className="border-t pt-3 mt-3">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Total Weekly Income:</span>
                  <span className="text-2xl font-bold text-green-600">${totalWeeklyIncome}</span>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Available Deals</CardTitle>
          <CardDescription>Check for new sponsorship opportunities</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {gameState.availableNILDeals.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-500 mb-4">Check for new NIL deal opportunities</p>
              <Button onClick={checkDeals}>
                <TrendingUp className="w-4 h-4 mr-2" />
                Check for Deals
              </Button>
            </div>
          ) : (
            gameState.availableNILDeals.map((deal) => (
              <div key={deal.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-lg">{deal.brand}</h3>
                    <Badge variant="outline" className="mt-1 capitalize">
                      {deal.tier} Tier
                    </Badge>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">${deal.weeklyPay}</div>
                    <div className="text-sm text-slate-500">per week</div>
                  </div>
                </div>
                <div className="mb-3 text-sm">
                  <p className="text-slate-500">
                    Duration: {deal.weeksRemaining} weeks •
                    Total: ${deal.weeklyPay * deal.weeksRemaining}
                  </p>
                </div>
                <Button onClick={() => signDeal(deal.id)} className="w-full">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Sign Deal
                </Button>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>NIL Requirements</CardTitle>
          <CardDescription>Your current eligibility status</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex justify-between">
            <span>Reputation:</span>
            <span className="font-bold">{gameState.reputation}</span>
          </div>
          <div className="flex justify-between">
            <span>Performance Rating:</span>
            <span className="font-bold">
              {Math.floor(Object.values(gameState.stats).reduce((a, b) => a + b, 0) / 9)}
            </span>
          </div>
          <div className="text-xs text-slate-500 mt-4">
            Higher reputation and performance unlock better NIL deals
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
