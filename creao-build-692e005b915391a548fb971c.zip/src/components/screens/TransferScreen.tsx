// Transfer portal screen

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { type GameState } from '@/types/game';
import { COLLEGES } from '@/lib/game-data';
import { Users, Star } from 'lucide-react';

interface TransferScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

export const TransferScreen = ({ gameState, updateGameState }: TransferScreenProps) => {
  const availableColleges = COLLEGES.filter(c => c !== gameState.profile.college);

  const transferToCollege = (college: string, cost: number) => {
    if (gameState.currency.reputationPoints < cost) {
      alert('Not enough reputation points!');
      return;
    }

    updateGameState({
      profile: {
        ...gameState.profile,
        college,
      },
      currency: {
        ...gameState.currency,
        reputationPoints: gameState.currency.reputationPoints - cost,
      },
      transferHistory: [...gameState.transferHistory, college],
      currentScholarship: 'none',
      teamChemistry: 50,
      coachTrust: 50,
    });
  };

  const getTransferCost = (index: number) => {
    return 50 + index * 10;
  };

  const getTierFromIndex = (index: number) => {
    if (index < 3) return 1;
    if (index < 6) return 2;
    return 3;
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Current School</CardTitle>
          <CardDescription>Your current college program</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Users className="w-12 h-12 text-blue-600" />
            <div>
              <div className="text-2xl font-bold">{gameState.profile.college}</div>
              <div className="text-slate-500">
                {gameState.transferHistory.length > 0 &&
                  `Transferred ${gameState.transferHistory.length} time(s)`
                }
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Transfer Portal</CardTitle>
          <CardDescription>
            Transfer to another college program (costs reputation points)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
            <p className="text-sm text-yellow-800">
              ⚠️ Transferring will reset your scholarship to walk-on and reduce team chemistry and coach trust
            </p>
          </div>
          <div className="mb-4">
            <div className="text-sm text-slate-500">
              Available Reputation Points: <span className="font-bold text-blue-600">{gameState.currency.reputationPoints}</span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {availableColleges.map((college, index) => {
              const cost = getTransferCost(index);
              const tier = getTierFromIndex(index);
              const canAfford = gameState.currency.reputationPoints >= cost;

              return (
                <div key={college} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-bold">{college}</h3>
                      <div className="flex gap-1 mt-1">
                        {Array.from({ length: tier }).map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                    <Badge variant={canAfford ? 'default' : 'destructive'}>
                      {cost} RP
                    </Badge>
                  </div>
                  <Button
                    onClick={() => transferToCollege(college, cost)}
                    disabled={!canAfford}
                    className="w-full mt-2"
                    variant={canAfford ? 'default' : 'secondary'}
                  >
                    Transfer Here
                  </Button>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
