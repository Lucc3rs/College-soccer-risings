// Training screen with mini-games

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { type GameState, type PlayerStats } from '@/types/game';
import { getTrainingReward, ENERGY_COSTS, calculateXPForLevel, calculateLevelFromXP } from '@/lib/game-engine';
import { Target, Zap, Dribbble, Activity, Shield } from 'lucide-react';

interface TrainingScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

const TRAINING_ACTIVITIES = [
  { id: 'shooting', name: 'Shooting Accuracy', icon: Target, stat: 'shooting' as keyof PlayerStats },
  { id: 'passing', name: 'Passing Timing', icon: Zap, stat: 'passing' as keyof PlayerStats },
  { id: 'dribbling', name: 'Dribbling Challenge', icon: Dribbble, stat: 'dribbling' as keyof PlayerStats },
  { id: 'stamina', name: 'Stamina Sprint', icon: Activity, stat: 'stamina' as keyof PlayerStats },
  { id: 'reflexes', name: 'GK Reflexes', icon: Shield, stat: 'defending' as keyof PlayerStats },
];

export const TrainingScreen = ({ gameState, updateGameState }: TrainingScreenProps) => {
  const [selectedActivity, setSelectedActivity] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);
  const [gameActive, setGameActive] = useState(false);
  const [targetButton, setTargetButton] = useState<number>(0); // For GK and dribbling
  const [buttonSequence, setButtonSequence] = useState<number[]>([]); // For zig-zag dribbling
  const [targetSequence, setTargetSequence] = useState<number[]>([]); // For passing accuracy
  const [sprintPhase, setSprintPhase] = useState<'ready' | 'sprint' | 'rest'>('ready'); // For stamina

  const startMiniGame = (activityId: string) => {
    if (gameState.energy < ENERGY_COSTS.training) {
      alert('Not enough energy!');
      return;
    }
    setSelectedActivity(activityId);
    setIsPlaying(true);
    setScore(0);
    setTimeLeft(10);
    setGameActive(true);

    // For GK reflexes - start with random target
    if (activityId === 'reflexes') {
      setTargetButton(Math.floor(Math.random() * 9));
    }

    // For dribbling - generate zig-zag sequence (alternating left/right)
    if (activityId === 'dribbling') {
      const sequence = [0, 1, 0, 1]; // left, right, left, right pattern
      setButtonSequence(sequence);
      setTargetButton(0); // Start with first button in sequence
    }

    // For passing - generate random sequence of 5 targets
    if (activityId === 'passing') {
      const sequence = Array.from({ length: 5 }, () => Math.floor(Math.random() * 5));
      setTargetSequence(sequence);
      setTargetButton(0); // Start with first target
    }

    // For stamina - initialize sprint phase and start rhythm cycling
    if (activityId === 'stamina') {
      setSprintPhase('ready');
      // Start with a brief ready period, then cycle between sprint and rest
      setTimeout(() => setSprintPhase('sprint'), 500);

      // Cycle sprint phases every 2 seconds
      const phaseTimer = setInterval(() => {
        setSprintPhase(prev => prev === 'sprint' ? 'rest' : 'sprint');
      }, 2000);

      // Clear phase timer when game ends
      setTimeout(() => clearInterval(phaseTimer), 10000);
    }

    // Simple timer-based game
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          setGameActive(false);
          // Use setTimeout to ensure we capture the final score after any last-second clicks
          setTimeout(() => {
            setScore(currentScore => {
              completeMiniGame(activityId, currentScore);
              return currentScore;
            });
          }, 0);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleClick = (buttonIndex?: number) => {
    if (!gameActive) return;

    // For GK reflexes - check if correct button was clicked
    if (selectedActivity === 'reflexes') {
      if (buttonIndex === targetButton) {
        setScore(prev => prev + 10);
        // Pick a new random target
        setTargetButton(Math.floor(Math.random() * 9));
      }
      return;
    }

    // For dribbling - check zig-zag sequence
    if (selectedActivity === 'dribbling') {
      const currentSequenceIndex = Math.floor(score / 10) % buttonSequence.length;
      if (buttonIndex === buttonSequence[currentSequenceIndex]) {
        setScore(prev => prev + 10);
      }
      return;
    }

    // For passing - check if correct target in sequence
    if (selectedActivity === 'passing') {
      const currentTargetIndex = Math.floor(score / 10) % targetSequence.length; // Loop through sequence
      if (buttonIndex === targetSequence[currentTargetIndex]) {
        setScore(prev => prev + 10);
      }
      return;
    }

    // For shooting - simple rapid fire clicking on moving target
    if (selectedActivity === 'shooting') {
      if (buttonIndex === targetButton) {
        setScore(prev => prev + 10);
        // Move target to new position
        setTargetButton(Math.floor(Math.random() * 3));
      }
      return;
    }

    // For stamina - rhythm-based sprint phases
    if (selectedActivity === 'stamina') {
      if (sprintPhase === 'sprint') {
        setScore(prev => prev + 10);
      }
      return;
    }

    // For other activities - simple click
    setScore(prev => prev + 10);
  };

  const completeMiniGame = (activityId: string, finalScore: number) => {
    const performance = Math.min(100, finalScore);
    const reward = getTrainingReward(activityId, performance);

    const newXP = gameState.xp + reward.xp;
    const newLevel = calculateLevelFromXP(newXP);
    const skillPointsGained = newLevel - gameState.level;

    const updatedStats = { ...gameState.stats };
    Object.entries(reward.statBonus).forEach(([stat, bonus]) => {
      updatedStats[stat as keyof PlayerStats] = Math.min(99, updatedStats[stat as keyof PlayerStats] + (bonus as number));
    });

    updateGameState({
      xp: newXP,
      level: newLevel,
      xpToNextLevel: calculateXPForLevel(newLevel),
      skillPoints: gameState.skillPoints + skillPointsGained,
      stats: updatedStats,
      energy: gameState.energy - ENERGY_COSTS.training,
      weeklyActivitiesDone: { ...gameState.weeklyActivitiesDone, training: true },
      currency: {
        ...gameState.currency,
        coins: gameState.currency.coins + 15,
      },
    });

    setTimeout(() => {
      setIsPlaying(false);
      setSelectedActivity(null);
    }, 2000);
  };

  if (isPlaying && selectedActivity) {
    const activity = TRAINING_ACTIVITIES.find(a => a.id === selectedActivity);

    // Special rendering for GK Reflexes training - reaction grid
    if (selectedActivity === 'reflexes') {
      return (
        <Card className="max-w-2xl mx-auto bg-white dark:bg-slate-800 border-2">
          <CardHeader className="bg-gradient-to-r from-yellow-600 to-orange-600 text-white">
            <CardTitle className="text-white text-2xl">{activity?.name}</CardTitle>
            <CardDescription className="text-yellow-100">Quick! Block the shots in all corners!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 bg-gradient-to-br from-yellow-50 to-orange-50 dark:bg-gradient-to-br dark:from-slate-900 dark:to-slate-800 p-6">
            <div className="text-center bg-white dark:bg-slate-800 rounded-lg p-4 shadow-lg">
              <div className="text-4xl font-bold text-slate-900 dark:text-white">{timeLeft}s</div>
              <div className="text-3xl font-bold text-yellow-600 mt-2">Blocks: {score / 10}</div>
            </div>

            {/* Visual reaction grid for GK training - 3x3 goal sections */}
            <div className="relative bg-gradient-to-b from-sky-300 to-green-400 dark:from-sky-900 dark:to-green-800 rounded-lg p-4 min-h-[320px] border-4 border-slate-800 dark:border-slate-600 shadow-2xl">
              <div className="absolute top-1 left-1/2 -translate-x-1/2 text-white font-bold text-xs bg-slate-800/80 px-2 py-1 rounded">
                GOAL NET
              </div>
              <div className="grid grid-cols-3 gap-2 mt-6 h-[280px]">
                {/* Generate 9 buttons (3x3 grid) */}
                {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((index) => (
                  <Button
                    key={index}
                    onClick={() => handleClick(index)}
                    disabled={!gameActive}
                    className={`text-4xl shadow-lg transform hover:scale-95 transition-all border-2 border-slate-700 ${
                      index === targetButton && gameActive
                        ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                        : 'bg-yellow-400/50 hover:bg-yellow-500'
                    }`}
                  >
                    {index === targetButton && gameActive ? '⚽' : '🧤'}
                  </Button>
                ))}
              </div>
            </div>

            {!gameActive && (
              <div className="text-center text-yellow-600 font-bold text-xl bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
                +{Math.min(100, score)} Performance! Amazing reflexes!
              </div>
            )}
          </CardContent>
        </Card>
      );
    }

    // Special rendering for Passing Timing - hit targets in sequence
    if (selectedActivity === 'passing') {
      const currentTargetIndex = Math.floor(score / 10) % targetSequence.length; // Loop through sequence
      return (
        <Card className="max-w-2xl mx-auto bg-white dark:bg-slate-800 border-2">
          <CardHeader className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white">
            <CardTitle className="text-white text-2xl">{activity?.name}</CardTitle>
            <CardDescription className="text-cyan-100">Hit the targets in order! Follow the sequence!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 bg-gradient-to-br from-cyan-50 to-blue-50 dark:bg-gradient-to-br dark:from-slate-900 dark:to-slate-800 p-6">
            <div className="text-center bg-white dark:bg-slate-800 rounded-lg p-4 shadow-lg">
              <div className="text-4xl font-bold text-slate-900 dark:text-white">{timeLeft}s</div>
              <div className="text-3xl font-bold text-cyan-600 mt-2">Passes: {score / 10}</div>
            </div>

            {/* Passing targets - 5 teammates in different positions */}
            <div className="relative bg-gradient-to-b from-green-400 to-green-600 dark:from-green-800 dark:to-green-900 rounded-lg p-6 min-h-[320px] border-4 border-white dark:border-slate-700">
              <div className="absolute top-2 left-1/2 -translate-x-1/2 text-white font-bold text-sm bg-slate-800/80 px-3 py-1 rounded">
                TRAINING FIELD
              </div>
              <div className="grid grid-cols-5 gap-3 mt-10 h-[250px] items-center">
                {[0, 1, 2, 3, 4].map((index) => {
                  const isCurrentTarget = gameActive && index === targetSequence[currentTargetIndex];
                  const isPastTarget = currentTargetIndex > targetSequence.indexOf(index) && targetSequence.slice(0, currentTargetIndex).includes(index);
                  return (
                    <div key={index} className="flex flex-col items-center gap-2">
                      <Button
                        onClick={() => handleClick(index)}
                        disabled={!gameActive}
                        className={`w-20 h-20 rounded-full text-3xl shadow-xl transform hover:scale-110 transition-all ${
                          isCurrentTarget
                            ? 'bg-yellow-400 hover:bg-yellow-500 border-4 border-yellow-600 animate-pulse'
                            : isPastTarget
                            ? 'bg-green-500 hover:bg-green-600 border-4 border-green-700'
                            : 'bg-cyan-400 hover:bg-cyan-500 border-4 border-cyan-600'
                        }`}
                      >
                        {isCurrentTarget ? '🎯' : isPastTarget ? '✅' : '👤'}
                      </Button>
                      {isCurrentTarget && (
                        <div className="text-xs font-bold text-white bg-yellow-600 px-2 py-1 rounded">
                          PASS HERE!
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {!gameActive && (
              <div className="text-center text-cyan-600 font-bold text-xl bg-cyan-50 dark:bg-cyan-900/20 p-4 rounded-lg">
                +{Math.min(100, score)} Performance! Perfect passing!
              </div>
            )}
          </CardContent>
        </Card>
      );
    }

    // Special rendering for Shooting Accuracy - hit moving targets
    if (selectedActivity === 'shooting') {
      return (
        <Card className="max-w-2xl mx-auto bg-white dark:bg-slate-800 border-2">
          <CardHeader className="bg-gradient-to-r from-red-600 to-orange-600 text-white">
            <CardTitle className="text-white text-2xl">{activity?.name}</CardTitle>
            <CardDescription className="text-red-100">Hit the target! Precision shooting!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 bg-gradient-to-br from-red-50 to-orange-50 dark:bg-gradient-to-br dark:from-slate-900 dark:to-slate-800 p-6">
            <div className="text-center bg-white dark:bg-slate-800 rounded-lg p-4 shadow-lg">
              <div className="text-4xl font-bold text-slate-900 dark:text-white">{timeLeft}s</div>
              <div className="text-3xl font-bold text-red-600 mt-2">Goals: {score / 10}</div>
            </div>

            {/* Shooting targets - 3 goal sections */}
            <div className="relative bg-gradient-to-b from-sky-400 to-green-500 dark:from-sky-800 dark:to-green-900 rounded-lg p-6 min-h-[280px] border-4 border-slate-800 dark:border-slate-600">
              <div className="absolute top-2 left-1/2 -translate-x-1/2 text-white font-bold text-sm bg-slate-800/80 px-3 py-1 rounded">
                GOAL 🥅
              </div>
              <div className="grid grid-cols-3 gap-4 mt-10 h-[200px]">
                {[0, 1, 2].map((index) => {
                  const isTarget = gameActive && index === targetButton;
                  return (
                    <Button
                      key={index}
                      onClick={() => handleClick(index)}
                      disabled={!gameActive}
                      className={`h-full text-5xl shadow-2xl transform hover:scale-95 transition-all border-4 ${
                        isTarget
                          ? 'bg-red-500 hover:bg-red-600 border-red-700 animate-pulse'
                          : 'bg-slate-200/50 hover:bg-slate-300/50 border-slate-600'
                      }`}
                    >
                      {isTarget ? '⚽' : ''}
                    </Button>
                  );
                })}
              </div>
            </div>

            {!gameActive && (
              <div className="text-center text-red-600 font-bold text-xl bg-red-50 dark:bg-red-900/20 p-4 rounded-lg">
                +{Math.min(100, score)} Performance! Deadly accuracy!
              </div>
            )}
          </CardContent>
        </Card>
      );
    }

    // Special rendering for Stamina Sprint - rhythm-based sprinting
    if (selectedActivity === 'stamina') {
      return (
        <Card className="max-w-2xl mx-auto bg-white dark:bg-slate-800 border-2">
          <CardHeader className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white">
            <CardTitle className="text-white text-2xl">{activity?.name}</CardTitle>
            <CardDescription className="text-emerald-100">Tap rapidly when the light is green!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 bg-gradient-to-br from-emerald-50 to-teal-50 dark:bg-gradient-to-br dark:from-slate-900 dark:to-slate-800 p-6">
            <div className="text-center bg-white dark:bg-slate-800 rounded-lg p-4 shadow-lg">
              <div className="text-4xl font-bold text-slate-900 dark:text-white">{timeLeft}s</div>
              <div className="text-3xl font-bold text-emerald-600 mt-2">Sprints: {score / 10}</div>
            </div>

            {/* Sprint track with rhythm indicator */}
            <div className="relative bg-gradient-to-r from-gray-400 via-gray-300 to-gray-400 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded-lg p-6 min-h-[250px] border-4 border-slate-700">
              <div className="absolute top-2 left-1/2 -translate-x-1/2 text-white font-bold text-sm bg-slate-800/80 px-3 py-1 rounded">
                SPRINT TRACK 🏃
              </div>
              <div className="flex flex-col items-center justify-center h-[200px] gap-6 mt-6">
                <div className={`w-32 h-32 rounded-full flex items-center justify-center text-6xl font-bold transition-all ${
                  sprintPhase === 'sprint' ? 'bg-green-500 text-white animate-pulse' : 'bg-red-500 text-white'
                }`}>
                  {sprintPhase === 'sprint' ? '🟢' : '🔴'}
                </div>
                <Button
                  onClick={() => handleClick()}
                  disabled={!gameActive}
                  className="w-full h-24 text-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold shadow-xl"
                >
                  {sprintPhase === 'sprint' ? '🏃 SPRINT! 🏃' : 'Wait...'}
                </Button>
              </div>
            </div>

            {!gameActive && (
              <div className="text-center text-emerald-600 font-bold text-xl bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-lg">
                +{Math.min(100, score)} Performance! Unstoppable endurance!
              </div>
            )}
          </CardContent>
        </Card>
      );
    }

    // Special rendering for Dribbling Challenge - zigzag speed dribble
    if (selectedActivity === 'dribbling') {
      return (
        <Card className="max-w-2xl mx-auto bg-white dark:bg-slate-800 border-2">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-violet-600 text-white">
            <CardTitle className="text-white text-2xl">{activity?.name}</CardTitle>
            <CardDescription className="text-purple-100">Click the ball as it zigzags down the field!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 bg-gradient-to-br from-purple-50 to-violet-50 dark:bg-gradient-to-br dark:from-slate-900 dark:to-slate-800 p-6">
            <div className="text-center bg-white dark:bg-slate-800 rounded-lg p-4 shadow-lg">
              <div className="text-4xl font-bold text-slate-900 dark:text-white">{timeLeft}s</div>
              <div className="text-3xl font-bold text-purple-600 mt-2">Touches: {score / 10}</div>
            </div>

            {/* Visual zigzag dribbling drill */}
            <div className="relative bg-gradient-to-b from-green-300 to-green-500 dark:from-green-900 dark:to-green-700 rounded-lg p-4 min-h-[350px] border-4 border-white dark:border-slate-700 shadow-inner">
              <div className="absolute top-2 left-1/2 -translate-x-1/2 text-slate-900 dark:text-slate-200 font-bold text-sm bg-white/80 dark:bg-slate-800/80 px-3 py-1 rounded">
                Zigzag Sprint! ⚡
              </div>
              <div className="flex flex-col gap-3 mt-10">
                {/* Zigzag pattern: left (0), right (1), left (0), right (1) */}
                {[0, 1, 0, 1].map((position, index) => {
                  const currentSequenceIndex = Math.floor(score / 10) % buttonSequence.length;
                  const isTarget = gameActive && index === currentSequenceIndex;
                  return (
                    <div key={index} className={position === 0 ? 'flex justify-start' : 'flex justify-end'}>
                      <Button
                        onClick={() => handleClick(position)}
                        disabled={!gameActive}
                        className={`w-16 h-16 shadow-xl text-4xl rounded-full transform hover:scale-110 transition-all p-0 border-4 ${
                          isTarget
                            ? 'bg-yellow-400 hover:bg-yellow-500 border-yellow-600 animate-pulse'
                            : 'bg-white hover:bg-gray-100 border-purple-600'
                        }`}
                      >
                        ⚽
                      </Button>
                    </div>
                  );
                })}
              </div>
            </div>

            {!gameActive && (
              <div className="text-center text-purple-600 font-bold text-xl bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
                +{Math.min(100, score)} Performance! Lightning dribbling!
              </div>
            )}
          </CardContent>
        </Card>
      );
    }

    // Default rendering for other training activities
    return (
      <Card className="max-w-2xl mx-auto bg-white dark:bg-slate-800 border-2">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardTitle className="text-white text-2xl">{activity?.name}</CardTitle>
          <CardDescription className="text-blue-100">Click as fast as you can!</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 bg-slate-50 dark:bg-slate-900 p-6">
          <div className="text-center bg-white dark:bg-slate-800 rounded-lg p-6 shadow-lg">
            <div className="text-6xl font-bold text-slate-900 dark:text-white">{timeLeft}s</div>
            <div className="text-4xl font-bold text-green-600 mt-4">{score}</div>
          </div>
          <Button
            onClick={() => handleClick()}
            disabled={!gameActive}
            className="w-full h-32 text-2xl bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold shadow-xl"
            size="lg"
          >
            {gameActive ? 'CLICK!' : 'Training Complete!'}
          </Button>
          {!gameActive && (
            <div className="text-center text-green-600 font-bold text-xl bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
              +{Math.min(100, score)} Performance!
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-r from-slate-800 to-slate-900 border-2 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white text-2xl">Training Center</CardTitle>
          <CardDescription className="text-slate-300 text-base">
            Complete mini-games to improve your skills and earn XP
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4 flex-wrap">
            <div className="text-sm font-semibold text-white bg-slate-700 px-3 py-1 rounded">
              Energy: {gameState.energy} / {gameState.maxEnergy}
            </div>
            <Badge variant={gameState.energy >= ENERGY_COSTS.training ? 'default' : 'destructive'}>
              Cost: {ENERGY_COSTS.training} energy
            </Badge>
            {gameState.weeklyActivitiesDone.training && (
              <Badge variant="secondary">Training Complete This Week</Badge>
            )}
          </div>
          <Progress value={(gameState.energy / gameState.maxEnergy) * 100} className="mb-4" />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {TRAINING_ACTIVITIES.map((activity) => {
          const Icon = activity.icon;
          const currentStat = gameState.stats[activity.stat];
          return (
            <Card key={activity.id} className="bg-white dark:bg-slate-800 border-2 hover:shadow-xl transition-shadow">
              <CardHeader className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-slate-700 dark:to-slate-600">
                <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
                  <Icon className="w-5 h-5" />
                  {activity.name}
                </CardTitle>
                <CardDescription className="text-slate-700 dark:text-slate-300 font-medium">
                  Current {activity.stat}: {currentStat}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <Progress value={currentStat} className="mb-3" />
                <Button
                  onClick={() => startMiniGame(activity.id)}
                  disabled={gameState.energy < ENERGY_COSTS.training}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold"
                >
                  Train
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
