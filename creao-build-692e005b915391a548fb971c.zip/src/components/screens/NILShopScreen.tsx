// NIL Shop screen for purchasing gear and customization items with NIL money

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { type GameState, type InventoryItem } from '@/types/game';
import { DollarSign, ShoppingBag, Shirt, User, Home, Check, AlertCircle, Sparkles } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface NILShopScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

// Shop inventory items
const SHOP_ITEMS: InventoryItem[] = [
  // Gear Items (Performance equipment)
  {
    id: 'cleats_basic',
    name: 'Pro Cleats',
    category: 'gear',
    description: 'High-quality cleats for better performance',
    price: 500,
    statBoosts: { pace: 2, dribbling: 1 },
    equipped: false,
    rarity: 'common',
  },
  {
    id: 'cleats_elite',
    name: 'Elite Speed Boots',
    category: 'gear',
    description: 'Top-tier boots worn by professionals',
    price: 1500,
    statBoosts: { pace: 5, dribbling: 3, shooting: 2 },
    equipped: false,
    rarity: 'epic',
  },
  {
    id: 'gloves_gk',
    name: 'Goalkeeper Gloves',
    category: 'gear',
    description: 'Professional-grade gloves with superior grip',
    price: 800,
    statBoosts: { defending: 4, confidence: 2 },
    equipped: false,
    rarity: 'rare',
  },
  {
    id: 'training_kit',
    name: 'Advanced Training Kit',
    category: 'gear',
    description: 'Complete training gear for serious athletes',
    price: 1200,
    statBoosts: { stamina: 3, strength: 2, pace: 1 },
    equipped: false,
    rarity: 'rare',
  },
  {
    id: 'compression_gear',
    name: 'Performance Compression Set',
    category: 'gear',
    description: 'Improves recovery and endurance',
    price: 600,
    statBoosts: { stamina: 3, strength: 1 },
    equipped: false,
    rarity: 'common',
  },
  {
    id: 'captain_armband',
    name: 'Captain Armband',
    category: 'gear',
    description: 'Show your leadership on the field',
    price: 2000,
    statBoosts: { leadership: 5, confidence: 3 },
    equipped: false,
    rarity: 'legendary',
  },

  // Character Customization
  {
    id: 'haircut_fade',
    name: 'Fresh Fade Haircut',
    category: 'character',
    description: 'Look good, play good',
    price: 200,
    statBoosts: { confidence: 1 },
    equipped: false,
    rarity: 'common',
  },
  {
    id: 'tattoo_sleeve',
    name: 'Athletic Tattoo Sleeve',
    category: 'character',
    description: 'Custom ink to stand out',
    price: 1000,
    statBoosts: { confidence: 2 },
    equipped: false,
    rarity: 'rare',
  },
  {
    id: 'celebration_move',
    name: 'Signature Celebration',
    category: 'character',
    description: 'Unique goal celebration animation',
    price: 800,
    statBoosts: { confidence: 2, leadership: 1 },
    equipped: false,
    rarity: 'rare',
  },
  {
    id: 'wristband_set',
    name: 'Designer Wristbands',
    category: 'character',
    description: 'Stylish accessories for game day',
    price: 300,
    statBoosts: { confidence: 1 },
    equipped: false,
    rarity: 'common',
  },

  // Dorm Room Items
  {
    id: 'gaming_setup',
    name: 'Gaming Setup',
    category: 'dorm',
    description: 'High-end PC and console for downtime',
    price: 2500,
    statBoosts: { confidence: 2 },
    equipped: false,
    rarity: 'epic',
  },
  {
    id: 'mini_fridge',
    name: 'Mini Fridge',
    category: 'dorm',
    description: 'Keep your energy drinks cold',
    price: 400,
    equipped: false,
    rarity: 'common',
  },
  {
    id: 'sound_system',
    name: 'Premium Sound System',
    category: 'dorm',
    description: 'Pump yourself up before matches',
    price: 1500,
    statBoosts: { confidence: 2, leadership: 1 },
    equipped: false,
    rarity: 'rare',
  },
  {
    id: 'trophy_case',
    name: 'Trophy Display Case',
    category: 'dorm',
    description: 'Show off your achievements',
    price: 800,
    statBoosts: { confidence: 3 },
    equipped: false,
    rarity: 'rare',
  },
  {
    id: 'poster_collection',
    name: 'Soccer Legends Posters',
    category: 'dorm',
    description: 'Get inspired by the greats',
    price: 150,
    statBoosts: { confidence: 1 },
    equipped: false,
    rarity: 'common',
  },
  {
    id: 'massage_chair',
    name: 'Recovery Massage Chair',
    category: 'dorm',
    description: 'Ultimate relaxation and recovery',
    price: 3000,
    statBoosts: { stamina: 2, confidence: 2 },
    equipped: false,
    rarity: 'legendary',
  },
];

const rarityColors = {
  common: 'bg-slate-100 text-slate-700 border-slate-300',
  rare: 'bg-blue-100 text-blue-700 border-blue-300',
  epic: 'bg-purple-100 text-purple-700 border-purple-300',
  legendary: 'bg-yellow-100 text-yellow-700 border-yellow-300',
};

const categoryIcons = {
  gear: Shirt,
  character: User,
  dorm: Home,
};

export const NILShopScreen = ({ gameState, updateGameState }: NILShopScreenProps) => {
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'gear' | 'character' | 'dorm'>('all');

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 3000);
  };

  const purchaseItem = (item: InventoryItem) => {
    // Ensure inventory exists
    const inventory = gameState.inventory || [];

    // Check if already owned
    const alreadyOwned = inventory.some(i => i.id === item.id);
    if (alreadyOwned) {
      showMessage('error', 'You already own this item!');
      return;
    }

    // Check if can afford
    if (gameState.currency.nilMoney < item.price) {
      showMessage('error', `Not enough NIL money! Need $${item.price - gameState.currency.nilMoney} more.`);
      return;
    }

    // Purchase item
    const newItem = { ...item, equipped: false };
    const newInventory = [...inventory, newItem];

    updateGameState({
      inventory: newInventory,
      currency: {
        ...gameState.currency,
        nilMoney: gameState.currency.nilMoney - item.price,
      },
    });

    showMessage('success', `Purchased ${item.name}!`);
  };

  const equipItem = (itemId: string) => {
    // Ensure inventory exists
    const inventory = gameState.inventory || [];

    const updatedInventory = inventory.map(item => {
      if (item.id === itemId) {
        return { ...item, equipped: !item.equipped };
      }
      // Only one item per category can be equipped for gear
      if (item.category === 'gear') {
        const clickedItem = inventory.find(i => i.id === itemId);
        if (clickedItem?.category === 'gear' && item.equipped) {
          return { ...item, equipped: false };
        }
      }
      return item;
    });

    // Calculate stat boosts from equipped items
    let statBoosts = { ...gameState.stats };
    updatedInventory.forEach(item => {
      if (item.equipped && item.statBoosts) {
        Object.entries(item.statBoosts).forEach(([stat, boost]) => {
          statBoosts = {
            ...statBoosts,
            [stat]: (statBoosts[stat as keyof typeof statBoosts] || 0) + (boost || 0),
          };
        });
      }
    });

    updateGameState({
      inventory: updatedInventory,
      stats: statBoosts,
    });
  };

  const filteredItems = selectedCategory === 'all'
    ? SHOP_ITEMS
    : SHOP_ITEMS.filter(item => item.category === selectedCategory);

  // Ensure inventory exists
  const inventory = gameState.inventory || [];
  const ownedItemIds = inventory.map(item => item.id);

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingBag className="w-6 h-6" />
            NIL Money Shop
          </CardTitle>
          <CardDescription>
            Use your NIL money to buy gear, customize your character, and upgrade your dorm room
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DollarSign className="w-8 h-8 text-green-600" />
              <div>
                <span className="text-3xl font-bold text-green-600">${gameState.currency.nilMoney}</span>
                <p className="text-sm text-slate-500">NIL Money Available</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">{inventory.length}</div>
              <p className="text-sm text-slate-500">Items Owned</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Message Alert */}
      {message && (
        <Alert variant={message.type === 'error' ? 'destructive' : 'default'}>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      {/* Tabs for Categories */}
      <Tabs value={selectedCategory} onValueChange={(v) => setSelectedCategory(v as typeof selectedCategory)}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Items</TabsTrigger>
          <TabsTrigger value="gear">Gear</TabsTrigger>
          <TabsTrigger value="character">Character</TabsTrigger>
          <TabsTrigger value="dorm">Dorm</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedCategory} className="mt-4">
          {/* My Inventory Section */}
          {inventory.length > 0 && (
            <Card className="mb-4">
              <CardHeader>
                <CardTitle className="text-lg">My Inventory</CardTitle>
                <CardDescription>Your purchased items - Click to equip/unequip</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {inventory
                    .filter(item => selectedCategory === 'all' || item.category === selectedCategory)
                    .map((item) => {
                      const Icon = categoryIcons[item.category];
                      return (
                        <Card
                          key={item.id}
                          className={`cursor-pointer transition-all ${item.equipped ? 'ring-2 ring-green-500' : ''} ${rarityColors[item.rarity]}`}
                          onClick={() => equipItem(item.id)}
                        >
                          <CardHeader className="pb-2">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-2">
                                <Icon className="w-4 h-4" />
                                <CardTitle className="text-sm">{item.name}</CardTitle>
                              </div>
                              {item.equipped && <Check className="w-5 h-5 text-green-600" />}
                            </div>
                          </CardHeader>
                          <CardContent className="pb-3">
                            <p className="text-xs mb-2">{item.description}</p>
                            {item.statBoosts && (
                              <div className="text-xs space-y-1">
                                {Object.entries(item.statBoosts).map(([stat, boost]) => (
                                  <div key={stat} className="flex justify-between">
                                    <span className="capitalize">{stat}:</span>
                                    <span className="text-green-600 font-bold">+{boost}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      );
                    })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Shop Items Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredItems.map((item) => {
              const Icon = categoryIcons[item.category];
              const owned = ownedItemIds.includes(item.id);
              const canAfford = gameState.currency.nilMoney >= item.price;

              return (
                <Card key={item.id} className={owned ? 'opacity-50' : ''}>
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <Badge variant="outline" className={rarityColors[item.rarity]}>
                        {item.rarity}
                      </Badge>
                      {owned && (
                        <Badge variant="default" className="bg-green-600">
                          <Check className="w-3 h-3 mr-1" />
                          Owned
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Icon className="w-5 h-5" />
                      {item.name}
                    </CardTitle>
                    <CardDescription>{item.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {item.statBoosts && (
                      <div className="p-3 bg-slate-50 rounded space-y-1">
                        <div className="flex items-center gap-1 text-xs font-semibold text-slate-600 mb-2">
                          <Sparkles className="w-3 h-3" />
                          Stat Boosts
                        </div>
                        {Object.entries(item.statBoosts).map(([stat, boost]) => (
                          <div key={stat} className="flex justify-between text-sm">
                            <span className="capitalize text-slate-600">{stat}:</span>
                            <span className="text-green-600 font-bold">+{boost}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex items-center justify-between pt-2 border-t">
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4 text-green-600" />
                        <span className="text-xl font-bold text-green-600">{item.price}</span>
                      </div>
                      <Button
                        onClick={() => purchaseItem(item)}
                        disabled={owned || !canAfford}
                        size="sm"
                      >
                        {owned ? 'Owned' : canAfford ? 'Buy Now' : 'Not Enough $'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
