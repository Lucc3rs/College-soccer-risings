// Full Season Schedule Screen with Regular Season, Conference Playoffs, and National Tournament

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { type GameState, type ScheduledMatch } from '@/types/game';
import { generateSeasonSchedule, generateConferencePlayoffSchedule, generateNationalTournamentSchedule } from '@/lib/game-engine';
import { Trophy, Calendar, Target, Award, CheckCircle2, Circle, Lock, TrendingUp } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface FullScheduleScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

export const FullScheduleScreen = ({ gameState, updateGameState }: FullScheduleScreenProps) => {
  // Initialize schedule if it doesn't exist or is undefined (for backward compatibility)
  useEffect(() => {
    if (!gameState.seasonSchedule || gameState.seasonSchedule.length === 0) {
      const initialSchedule = generateSeasonSchedule(gameState.level);
      updateGameState({
        seasonSchedule: initialSchedule,
        phase: 'Regular Season',
        regularSeasonWins: gameState.regularSeasonWins ?? 0,
        regularSeasonLosses: gameState.regularSeasonLosses ?? 0,
        regularSeasonTies: gameState.regularSeasonTies ?? 0,
      });
    }
  }, []);

  // Safely access seasonSchedule with fallback to empty array
  const seasonSchedule = gameState.seasonSchedule || [];
  const regularSeasonGames = seasonSchedule.filter(m => m.phase === 'Regular Season');
  const conferencePlayoffGames = seasonSchedule.filter(m => m.phase === 'Conference Playoffs');
  const nationalTournamentGames = seasonSchedule.filter(m => m.phase === 'National Tournament');

  const completedRegularSeason = regularSeasonGames.filter(m => m.completed).length;
  const totalRegularSeason = regularSeasonGames.length;

  // Calculate win/loss/tie record
  const regularSeasonRecord = {
    wins: gameState.regularSeasonWins,
    losses: gameState.regularSeasonLosses,
    ties: gameState.regularSeasonTies,
  };

  const totalGamesPlayed = regularSeasonRecord.wins + regularSeasonRecord.losses + regularSeasonRecord.ties;
  const winPercentage = totalGamesPlayed > 0
    ? (regularSeasonRecord.wins / totalGamesPlayed * 100).toFixed(1)
    : '0.0';

  const qualifiedForPlayoffs = regularSeasonRecord.wins >= 10; // Need 10+ wins to qualify

  // Generate week-by-week standings showing cumulative record
  const generateWeekByWeekStandings = () => {
    const standings: Array<{
      week: number;
      wins: number;
      losses: number;
      ties: number;
      winPct: string;
      position: number;
    }> = [];

    let cumulativeWins = 0;
    let cumulativeLosses = 0;
    let cumulativeTies = 0;

    for (let week = 1; week <= gameState.week; week++) {
      const weekMatch = regularSeasonGames.find(m => m.week === week && m.completed);

      if (weekMatch && weekMatch.result) {
        const isTie = weekMatch.score && weekMatch.score.player === weekMatch.score.opponent;

        if (weekMatch.result.won) {
          cumulativeWins++;
        } else if (isTie) {
          cumulativeTies++;
        } else {
          cumulativeLosses++;
        }

        const totalGames = cumulativeWins + cumulativeLosses + cumulativeTies;
        const winPct = totalGames > 0 ? ((cumulativeWins / totalGames) * 100).toFixed(1) : '0.0';

        // Calculate position (1-4 based on win percentage)
        // This is a simplified version - in a real league, this would compare against other teams
        const position = winPct >= '75.0' ? 1 : winPct >= '60.0' ? 2 : winPct >= '45.0' ? 3 : 4;

        standings.push({
          week,
          wins: cumulativeWins,
          losses: cumulativeLosses,
          ties: cumulativeTies,
          winPct,
          position,
        });
      }
    }

    return standings;
  };

  const weekByWeekStandings = generateWeekByWeekStandings();

  const renderMatchRow = (match: ScheduledMatch, index: number) => {
    const getDifficultyColor = (difficulty: number) => {
      if (difficulty < 60) return 'text-green-600 dark:text-green-400';
      if (difficulty < 75) return 'text-yellow-600 dark:text-yellow-400';
      return 'text-red-600 dark:text-red-400';
    };

    const getDifficultyLabel = (difficulty: number) => {
      if (difficulty < 60) return 'Easy';
      if (difficulty < 75) return 'Medium';
      return 'Hard';
    };

    const getMomentsCount = (difficulty: number) => {
      if (difficulty < 60) return '2-3';
      if (difficulty < 75) return '3-4';
      return '4-6';
    };

    return (
      <div
        key={match.id}
        className={`flex items-center justify-between p-4 rounded-lg border ${
          match.completed
            ? 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
            : match.week === gameState.week
            ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700'
            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-600'
        }`}
      >
        <div className="flex items-center gap-4 flex-1">
          <div className="w-12 text-center">
            {match.completed ? (
              <CheckCircle2 className="w-6 h-6 text-green-600 dark:text-green-400 mx-auto" />
            ) : match.week === gameState.week ? (
              <Target className="w-6 h-6 text-blue-600 dark:text-blue-400 mx-auto" />
            ) : match.week < gameState.week ? (
              <Circle className="w-6 h-6 text-slate-400 mx-auto" />
            ) : (
              <Lock className="w-6 h-6 text-slate-300 dark:text-slate-600 mx-auto" />
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-900 dark:text-white">
                Week {match.week}
              </span>
              <span className="text-slate-600 dark:text-slate-300">vs {match.opponent}</span>
            </div>
            <div className="flex items-center gap-3 mt-1">
              <Badge variant="outline" className={getDifficultyColor(match.opponentDifficulty)}>
                {getDifficultyLabel(match.opponentDifficulty)} ({match.opponentDifficulty})
              </Badge>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {getMomentsCount(match.opponentDifficulty)} moments
              </span>
            </div>
          </div>
          {match.result && (
            <div className="text-right">
              <div className={`text-lg font-bold ${
                match.result.won
                  ? 'text-green-600'
                  : match.score && match.score.player === match.score.opponent
                  ? 'text-yellow-600'
                  : 'text-red-600'
              }`}>
                {match.result.won
                  ? 'W'
                  : match.score && match.score.player === match.score.opponent
                  ? 'T'
                  : 'L'}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                {match.result.performance.toFixed(0)}% perf
              </div>
            </div>
          )}
          {match.week === gameState.week && !match.completed && (
            <Badge variant="default" className="bg-blue-600">Current Week</Badge>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
          <CardTitle className="text-white text-2xl flex items-center gap-2">
            <Calendar className="w-6 h-6" />
            Full Season Schedule
          </CardTitle>
          <CardDescription className="text-indigo-100">
            {gameState.season} • {gameState.phase}
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900 dark:to-indigo-900 rounded-lg border border-blue-200 dark:border-blue-700">
              <div className="text-sm font-semibold text-blue-700 dark:text-blue-300">Regular Season Record</div>
              <div className="text-3xl font-bold text-slate-900 dark:text-white">
                {regularSeasonRecord.wins}-{regularSeasonRecord.losses}-{regularSeasonRecord.ties}
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {winPercentage}% win rate
              </div>
            </div>
            <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900 dark:to-pink-900 rounded-lg border border-purple-200 dark:border-purple-700">
              <div className="text-sm font-semibold text-purple-700 dark:text-purple-300">Games Played</div>
              <div className="text-3xl font-bold text-slate-900 dark:text-white">
                {completedRegularSeason}/{totalRegularSeason}
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {totalRegularSeason - completedRegularSeason} remaining
              </div>
            </div>
            <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900 dark:to-emerald-900 rounded-lg border border-green-200 dark:border-green-700">
              <div className="text-sm font-semibold text-green-700 dark:text-green-300">Playoff Status</div>
              <div className="text-xl font-bold text-slate-900 dark:text-white">
                {qualifiedForPlayoffs ? 'Qualified ✓' : 'Need 10 Wins'}
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {qualifiedForPlayoffs ? 'Conference playoffs' : `${10 - regularSeasonRecord.wins} wins needed`}
              </div>
            </div>
          </div>

          <Tabs defaultValue="regular" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="regular" className="flex items-center gap-2">
                <Trophy className="w-4 h-4" />
                Regular Season
              </TabsTrigger>
              <TabsTrigger value="standings" className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Standings
              </TabsTrigger>
              <TabsTrigger value="conference" disabled={conferencePlayoffGames.length === 0} className="flex items-center gap-2">
                <Award className="w-4 h-4" />
                Conference Playoffs
              </TabsTrigger>
              <TabsTrigger value="national" disabled={nationalTournamentGames.length === 0} className="flex items-center gap-2">
                <Trophy className="w-4 h-4" />
                National Tournament
              </TabsTrigger>
            </TabsList>

            <TabsContent value="regular" className="mt-4">
              <div className="space-y-2">
                {regularSeasonGames.length === 0 ? (
                  <div className="text-center py-8 text-slate-500">
                    No regular season schedule generated yet.
                  </div>
                ) : (
                  regularSeasonGames.map((match, index) => renderMatchRow(match, index))
                )}
              </div>
            </TabsContent>

            <TabsContent value="standings" className="mt-4">
              {weekByWeekStandings.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  No games played yet. Complete matches to see your weekly standings!
                </div>
              ) : (
                <div className="bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-20">Week</TableHead>
                        <TableHead className="w-24">Record</TableHead>
                        <TableHead className="w-24">Win %</TableHead>
                        <TableHead className="w-28">Position</TableHead>
                        <TableHead>Trend</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {weekByWeekStandings.map((standing, index) => {
                        const previousPosition = index > 0 ? weekByWeekStandings[index - 1].position : standing.position;
                        const positionChange = previousPosition - standing.position;

                        return (
                          <TableRow key={standing.week} className={standing.week === gameState.week ? 'bg-blue-50 dark:bg-blue-900/20' : ''}>
                            <TableCell className="font-semibold">
                              {standing.week}
                              {standing.week === gameState.week && (
                                <Badge variant="outline" className="ml-2 text-xs">Current</Badge>
                              )}
                            </TableCell>
                            <TableCell className="font-mono">
                              {standing.wins}-{standing.losses}-{standing.ties}
                            </TableCell>
                            <TableCell className="font-semibold">
                              {standing.winPct}%
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className={
                                  standing.position === 1
                                    ? 'bg-yellow-100 text-yellow-800 border-yellow-300 dark:bg-yellow-900 dark:text-yellow-100'
                                    : standing.position === 2
                                    ? 'bg-slate-100 text-slate-800 border-slate-300 dark:bg-slate-700 dark:text-slate-100'
                                    : standing.position === 3
                                    ? 'bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900 dark:text-orange-100'
                                    : 'bg-red-100 text-red-800 border-red-300 dark:bg-red-900 dark:text-red-100'
                                }
                              >
                                #{standing.position}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {index > 0 && (
                                <span className={`flex items-center gap-1 ${
                                  positionChange > 0
                                    ? 'text-green-600 dark:text-green-400'
                                    : positionChange < 0
                                    ? 'text-red-600 dark:text-red-400'
                                    : 'text-slate-500'
                                }`}>
                                  {positionChange > 0 && (
                                    <>
                                      <TrendingUp className="w-4 h-4" />
                                      +{positionChange}
                                    </>
                                  )}
                                  {positionChange < 0 && (
                                    <>
                                      <TrendingUp className="w-4 h-4 rotate-180" />
                                      {positionChange}
                                    </>
                                  )}
                                  {positionChange === 0 && '—'}
                                </span>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>

            <TabsContent value="conference" className="mt-4">
              <div className="space-y-2">
                {conferencePlayoffGames.length === 0 ? (
                  <div className="text-center py-8">
                    <Lock className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
                    <div className="text-slate-600 dark:text-slate-400 font-semibold">Conference Playoffs Locked</div>
                    <div className="text-sm text-slate-500 dark:text-slate-500 mt-1">
                      Win at least 10 regular season games to qualify
                    </div>
                  </div>
                ) : (
                  conferencePlayoffGames.map((match, index) => renderMatchRow(match, index))
                )}
              </div>
            </TabsContent>

            <TabsContent value="national" className="mt-4">
              <div className="space-y-2">
                {nationalTournamentGames.length === 0 ? (
                  <div className="text-center py-8">
                    <Lock className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
                    <div className="text-slate-600 dark:text-slate-400 font-semibold">National Tournament Locked</div>
                    <div className="text-sm text-slate-500 dark:text-slate-500 mt-1">
                      Win the conference playoffs to advance
                    </div>
                  </div>
                ) : (
                  nationalTournamentGames.map((match, index) => renderMatchRow(match, index))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900">
        <CardHeader>
          <CardTitle className="text-lg">Schedule Info</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex items-start gap-2">
            <Trophy className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold">Regular Season:</span> 20 games with varying difficulty. Harder opponents have fewer moments.
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Award className="w-4 h-4 text-purple-600 dark:text-purple-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold">Conference Playoffs:</span> 3-round single elimination (Quarterfinal, Semifinal, Final). Requires 10+ regular season wins.
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Trophy className="w-4 h-4 text-yellow-600 dark:text-yellow-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold">National Tournament:</span> 4-round championship (Sweet 16, Elite 8, Final Four, Championship). Win conference to qualify.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
