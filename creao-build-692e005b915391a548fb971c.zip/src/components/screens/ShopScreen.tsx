// Shop screen for purchasing energy refills and max energy upgrades using coins

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { type GameState } from '@/types/game';
import { ShoppingCart, Zap, Award, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface ShopScreenProps {
  gameState: GameState;
  updateGameState: (updates: Partial<GameState>) => void;
}

interface StaminaUpgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  energyAmount: number;
  isMaxUpgrade?: boolean;
}

const STAMINA_PACKAGES: StaminaUpgrade[] = [
  // Energy restoration items
  { id: 'energy_small', name: 'Energy Drink', description: 'Restore 20 energy', cost: 100, energyAmount: 20 },
  { id: 'energy_medium', name: 'Recovery Session', description: 'Restore 50 energy', cost: 200, energyAmount: 50 },
  { id: 'energy_large', name: 'Full Rest Day', description: 'Restore all energy', cost: 350, energyAmount: 999 },

  // Max energy upgrades
  { id: 'max_energy_1', name: 'Max Energy Upgrade I', description: '+10 Max Energy', cost: 500, energyAmount: 10, isMaxUpgrade: true },
  { id: 'max_energy_2', name: 'Max Energy Upgrade II', description: '+20 Max Energy', cost: 1000, energyAmount: 20, isMaxUpgrade: true },
];

export const ShopScreen = ({ gameState, updateGameState }: ShopScreenProps) => {
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 3000);
  };

  const purchaseStaminaUpgrade = (pkg: StaminaUpgrade) => {
    // Check if player has enough coins
    if (gameState.currency.coins < pkg.cost) {
      showMessage('error', `Not enough coins! Need ${pkg.cost - gameState.currency.coins} more.`);
      return;
    }

    // Handle max energy upgrades
    if (pkg.isMaxUpgrade) {
      updateGameState({
        maxEnergy: gameState.maxEnergy + pkg.energyAmount,
        energy: gameState.energy + pkg.energyAmount, // Also restore the new max energy
        currency: {
          ...gameState.currency,
          coins: gameState.currency.coins - pkg.cost,
        },
      });
      showMessage('success', `Max Energy increased by ${pkg.energyAmount}!`);
      return;
    }

    // Handle energy refills
    const newEnergy = Math.min(gameState.maxEnergy, gameState.energy + pkg.energyAmount);
    const actualRestore = newEnergy - gameState.energy;

    if (actualRestore === 0) {
      showMessage('error', 'Energy is already full!');
      return;
    }

    updateGameState({
      energy: newEnergy,
      currency: {
        ...gameState.currency,
        coins: gameState.currency.coins - pkg.cost,
      },
    });

    showMessage('success', `Restored ${actualRestore} energy!`);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="w-6 h-6" />
            Energy Shop
          </CardTitle>
          <CardDescription>
            Use coins to restore energy and upgrade max energy capacity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-around">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-yellow-600">{gameState.currency.coins}</span>
              <span className="text-slate-500">Coins Available</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-purple-600">{gameState.energy}/{gameState.maxEnergy}</span>
              <span className="text-slate-500">Energy</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Message Alert */}
      {message && (
        <Alert variant={message.type === 'error' ? 'destructive' : 'default'}>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      {/* Stamina & Energy Packages */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {STAMINA_PACKAGES.map((pkg) => {
          const canAfford = gameState.currency.coins >= pkg.cost;
          const isEnergyFull = gameState.energy >= gameState.maxEnergy && !pkg.id.startsWith('max_energy');

          return (
            <Card key={pkg.id} className={!canAfford || isEnergyFull ? 'opacity-60' : ''}>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Zap className="w-5 h-5 text-purple-600" />
                  {pkg.name}
                </CardTitle>
                <CardDescription>{pkg.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {pkg.isMaxUpgrade ? (
                  <div className="p-3 bg-purple-50 rounded text-center">
                    <Award className="w-6 h-6 text-purple-600 mx-auto mb-1" />
                    <div className="text-sm text-purple-700">Permanent Upgrade</div>
                  </div>
                ) : (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Current Energy:</span>
                    <span className="font-bold">{gameState.energy}/{gameState.maxEnergy}</span>
                  </div>
                )}
                <Button
                  onClick={() => purchaseStaminaUpgrade(pkg)}
                  disabled={!canAfford || isEnergyFull}
                  className="w-full"
                >
                  {isEnergyFull ? 'Energy Full' : `Buy for ${pkg.cost} coins`}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
