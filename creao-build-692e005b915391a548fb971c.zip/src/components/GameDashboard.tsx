// Main game dashboard with all screens

import { useState } from 'react';
import { useGameState } from '@/hooks/useGameState';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  Trophy, Dumbbell, GraduationCap, Calendar, TrendingUp,
  DollarSign, Users, Award, ShoppingCart, ShoppingBag, RotateCcw, CalendarDays, Coins, Share2
} from 'lucide-react';
import { TrainingScreen } from '@/components/screens/TrainingScreen';
import { ScheduleScreen } from '@/components/screens/ScheduleScreen';
import { FullScheduleScreen } from '@/components/screens/FullScheduleScreen';
import { StatsScreen } from '@/components/screens/StatsScreen';
import { ScholarshipScreen } from '@/components/screens/ScholarshipScreen';
import { NILScreen } from '@/components/screens/NILScreen';
import { TransferScreen } from '@/components/screens/TransferScreen';
import { AchievementsScreen } from '@/components/screens/AchievementsScreen';
import { ShopScreen } from '@/components/screens/ShopScreen';
import { NILShopScreen } from '@/components/screens/NILShopScreen';
import { CoinShopScreen } from '@/components/screens/CoinShopScreen';
import { CollegeSelectionScreen } from '@/components/screens/CollegeSelectionScreen';
import { IntegrationsScreen } from '@/components/screens/IntegrationsScreen';
import { type GameState } from '@/types/game';

export const GameDashboard = () => {
  const { gameState, updateGameState, resetGame } = useGameState();
  const [activeScreen, setActiveScreen] = useState<'home' | 'training' | 'schedule' | 'fullschedule' | 'stats' | 'scholarship' | 'nil' | 'transfer' | 'achievements' | 'shop' | 'nilshop' | 'coinshop' | 'integrations'>('home');

  if (!gameState) return null;

  const handleRestartCareer = () => {
    if (confirm('Are you sure you want to restart your career? All progress will be lost!')) {
      resetGame();
    }
  };

  // Show college selection screen if in that phase
  if (gameState.phase === 'College Selection') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
        <div className="max-w-7xl mx-auto">
          <CollegeSelectionScreen gameState={gameState} updateGameState={updateGameState} />
        </div>
      </div>
    );
  }

  const statAverage = Math.floor(
    Object.values(gameState.stats).reduce((a, b) => a + b, 0) / 9
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div>
              <h1 className="text-2xl font-bold text-white">{gameState.profile.name}</h1>
              <p className="text-slate-300">
                {gameState.profile.position} • {gameState.isHighSchool ? gameState.profile.highSchool : gameState.profile.college} • {gameState.season}
              </p>
            </div>
            <Button
              onClick={handleRestartCareer}
              variant="ghost"
              size="sm"
              className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
              title="Restart Career"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex gap-6 text-sm">
            <div className="text-center">
              <div className="text-yellow-400 font-bold">{gameState.currency.coins}</div>
              <div className="text-slate-400">Coins</div>
            </div>
            <div className="text-center">
              <div className="text-blue-400 font-bold">{gameState.currency.reputationPoints}</div>
              <div className="text-slate-400">Rep</div>
            </div>
            {!gameState.isHighSchool && (
              <div className="text-center">
                <div className="text-green-400 font-bold">${gameState.currency.nilMoney}</div>
                <div className="text-slate-400">NIL</div>
              </div>
            )}
            <div className="text-center">
              <div className="text-purple-400 font-bold">{gameState.energy}/{gameState.maxEnergy}</div>
              <div className="text-slate-400">Energy</div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="bg-slate-800/50 border-b border-slate-700 overflow-x-auto">
        <div className="max-w-7xl mx-auto flex gap-2 p-2">
          {[
            { id: 'home', label: 'Home', icon: Trophy, showInHS: true },
            { id: 'training', label: 'Training', icon: Dumbbell, showInHS: true },
            { id: 'schedule', label: 'Schedule', icon: Calendar, showInHS: true },
            { id: 'fullschedule', label: 'Full Schedule', icon: CalendarDays, showInHS: true },
            { id: 'stats', label: 'Stats', icon: TrendingUp, showInHS: true },
            { id: 'coinshop', label: 'Coin Shop', icon: Coins, showInHS: true },
            { id: 'shop', label: 'Energy Shop', icon: ShoppingCart, showInHS: true },
            { id: 'integrations', label: 'Integrations', icon: Share2, showInHS: false },
            { id: 'nilshop', label: 'NIL Shop', icon: ShoppingBag, showInHS: false },
            { id: 'scholarship', label: 'Scholarship', icon: GraduationCap, showInHS: false },
            { id: 'nil', label: 'NIL Deals', icon: DollarSign, showInHS: false },
            { id: 'transfer', label: 'Transfer', icon: Users, showInHS: false },
            { id: 'achievements', label: 'Goals', icon: Award, showInHS: true },
          ]
            .filter(nav => gameState.isHighSchool ? nav.showInHS : true)
            .map((nav) => {
              const Icon = nav.icon;
              return (
                <Button
                  key={nav.id}
                  variant={activeScreen === nav.id ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveScreen(nav.id as typeof activeScreen)}
                  className={`flex items-center gap-2 ${activeScreen === nav.id ? 'text-white font-bold' : 'text-slate-200 hover:text-white'}`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="font-semibold">{nav.label}</span>
                </Button>
              );
            })}
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-4">
        {activeScreen === 'home' && <HomeScreen gameState={gameState} onNavigate={setActiveScreen} updateGameState={updateGameState} />}
        {activeScreen === 'training' && <TrainingScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'schedule' && <ScheduleScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'fullschedule' && <FullScheduleScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'stats' && <StatsScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'coinshop' && <CoinShopScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'shop' && <ShopScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'nilshop' && <NILShopScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'scholarship' && <ScholarshipScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'nil' && <NILScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'transfer' && <TransferScreen gameState={gameState} updateGameState={updateGameState} />}
        {activeScreen === 'achievements' && <AchievementsScreen gameState={gameState} />}
        {activeScreen === 'integrations' && <IntegrationsScreen gameState={gameState} updateGameState={updateGameState} />}
      </div>
    </div>
  );
};

// Home Screen Component
type ScreenType = 'home' | 'training' | 'schedule' | 'fullschedule' | 'stats' | 'scholarship' | 'nil' | 'transfer' | 'achievements' | 'shop' | 'nilshop' | 'coinshop' | 'integrations';

const HomeScreen = ({
  gameState,
  onNavigate,
  updateGameState
}: {
  gameState: GameState;
  onNavigate: (screen: ScreenType) => void;
  updateGameState: (updates: Partial<GameState>) => void;
}) => {
  const xpProgress = (gameState.xp / gameState.xpToNextLevel) * 100;
  const energyProgress = (gameState.energy / gameState.maxEnergy) * 100;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {/* Player Overview */}
      <Card className="md:col-span-2 bg-white dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
          <CardTitle className="text-white text-xl">Career Overview</CardTitle>
          <CardDescription className="text-blue-100">
            Week {gameState.week} • {gameState.phase}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 pt-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm font-semibold text-slate-700 dark:text-slate-300">Level</div>
              <div className="text-3xl font-bold text-slate-900 dark:text-white">{gameState.level}</div>
              <Progress value={xpProgress} className="mt-2" />
              <div className="text-xs font-medium text-slate-600 dark:text-slate-400 mt-1">
                {gameState.xp} / {gameState.xpToNextLevel} XP
              </div>
            </div>
            <div>
              <div className="text-sm font-semibold text-slate-700 dark:text-slate-300">Overall Rating</div>
              <div className="text-3xl font-bold text-slate-900 dark:text-white">
                {Math.floor(Object.values(gameState.stats).reduce((a, b) => a + b, 0) / 9)}
              </div>
              <div className="flex gap-2 mt-2">
                <Badge variant={gameState.isStarter ? 'default' : 'secondary'}>
                  {gameState.isStarter ? 'Starter' : 'Bench'}
                </Badge>
                <Badge variant="outline">
                  {gameState.isHighSchool ? 'High School' : gameState.currentScholarship}
                </Badge>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900 dark:to-indigo-900 rounded-lg border border-blue-200 dark:border-blue-700">
              <div className="text-xs font-semibold text-blue-700 dark:text-blue-300">GPA</div>
              <div className="text-xl font-bold text-slate-900 dark:text-white">{gameState.gpa.toFixed(2)}</div>
            </div>
            <div className="p-3 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900 dark:to-pink-900 rounded-lg border border-purple-200 dark:border-purple-700">
              <div className="text-xs font-semibold text-purple-700 dark:text-purple-300">Reputation</div>
              <div className="text-xl font-bold text-slate-900 dark:text-white">{gameState.reputation}</div>
            </div>
            <div className="p-3 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900 dark:to-emerald-900 rounded-lg border border-green-200 dark:border-green-700">
              <div className="text-xs font-semibold text-green-700 dark:text-green-300">Matches</div>
              <div className="text-xl font-bold text-slate-900 dark:text-white">{gameState.matchHistory.length}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <Card className="bg-white dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600">
        <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <CardTitle className="text-lg text-white">Relationships</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-6">
          <div>
            <div className="flex justify-between text-sm mb-1 font-semibold">
              <span className="text-slate-700 dark:text-slate-300">Team Chemistry</span>
              <span className="text-slate-900 dark:text-white">{gameState.teamChemistry}%</span>
            </div>
            <Progress value={gameState.teamChemistry} />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1 font-semibold">
              <span className="text-slate-700 dark:text-slate-300">Coach Trust</span>
              <span className="text-slate-900 dark:text-white">{gameState.coachTrust}%</span>
            </div>
            <Progress value={gameState.coachTrust} />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1 font-semibold">
              <span className="text-slate-700 dark:text-slate-300">Fan Support</span>
              <span className="text-slate-900 dark:text-white">{gameState.fanSupport}%</span>
            </div>
            <Progress value={gameState.fanSupport} />
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="md:col-span-2 lg:col-span-3 bg-white dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600">
        <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
          <CardTitle className="text-white">This Week</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Button
              onClick={() => onNavigate('training')}
              disabled={gameState.weeklyActivitiesDone.training}
              className="h-20 flex flex-col items-center justify-center bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold"
              variant={gameState.weeklyActivitiesDone.training ? 'secondary' : 'default'}
            >
              <Dumbbell className="w-6 h-6 mb-1" />
              <span>Training</span>
              {gameState.weeklyActivitiesDone.training && <span className="text-xs">Complete</span>}
            </Button>
            <Button
              onClick={() => onNavigate('schedule')}
              disabled={gameState.weeklyActivitiesDone.classes}
              className="h-20 flex flex-col items-center justify-center bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold"
              variant={gameState.weeklyActivitiesDone.classes ? 'secondary' : 'default'}
            >
              <GraduationCap className="w-6 h-6 mb-1" />
              <span>Classes</span>
              {gameState.weeklyActivitiesDone.classes && <span className="text-xs">Complete</span>}
            </Button>
            <Button
              onClick={() => onNavigate('schedule')}
              disabled={gameState.weeklyActivitiesDone.match || gameState.phase === 'Off-Season'}
              className="h-20 flex flex-col items-center justify-center bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold"
              variant={gameState.weeklyActivitiesDone.match ? 'secondary' : 'default'}
            >
              <Trophy className="w-6 h-6 mb-1" />
              <span>Match</span>
              {gameState.weeklyActivitiesDone.match && <span className="text-xs">Complete</span>}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GameDashboard;
