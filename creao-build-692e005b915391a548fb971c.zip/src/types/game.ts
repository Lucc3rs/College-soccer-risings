// Core game types for College Soccer Career RPG

export type Position = 'ST' | 'CAM' | 'CM' | 'CDM' | 'CB' | 'GK';

export type Season = 'High School Senior' | 'Freshman' | 'Sophomore' | 'Junior' | 'Senior';

export type Phase = 'Preseason' | 'Regular Season' | 'Conference Playoffs' | 'National Tournament' | 'Off-Season' | 'College Selection';

export type ScholarshipTier = 'none' | 'partial' | 'full';

export interface PlayerStats {
  pace: number;
  shooting: number;
  passing: number;
  dribbling: number;
  strength: number;
  stamina: number;
  defending: number;
  confidence: number;
  leadership: number;
}

export interface PlayerProfile {
  name: string;
  position: Position;
  appearance: {
    skinTone: number;
    hairStyle: number;
    hairColor: number;
  };
  college: string;
  highSchool: string;
}

export interface Currency {
  coins: number;
  reputationPoints: number;
  nilMoney: number;
}

export interface NILDeal {
  id: string;
  brand: string;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  weeklyPay: number;
  weeksRemaining: number;
  requirements: {
    minReputation: number;
    minPerformance: number;
  };
}

export interface ScholarshipOffer {
  id: string;
  college: string;
  tier: ScholarshipTier;
  value: number;
  requirements: string[];
}

export interface TransferOption {
  id: string;
  college: string;
  tier: number;
  cost: number;
  requirements: {
    minStats: number;
    minReputation: number;
  };
}

export interface MatchScenario {
  id: string;
  description: string;
  options: {
    action: string;
    statRequired: keyof PlayerStats;
    successChance: number;
  }[];
}

export interface MatchResult {
  won: boolean;
  performance: number;
  xpEarned: number;
  reputationEarned: number;
  highlights: string[];
}

export interface ScheduledMatch {
  id: string;
  week: number;
  opponent: string;
  opponentDifficulty: number;
  phase: 'Regular Season' | 'Conference Playoffs' | 'National Tournament';
  completed: boolean;
  result?: MatchResult;
  score?: { player: number; opponent: number };
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  unlocked: boolean;
  progress: number;
  target: number;
}

export type IntegrationType = 'social' | 'streaming' | 'brand' | 'media';

export interface SocialMediaIntegration {
  id: string;
  platform: 'Twitter' | 'Instagram' | 'TikTok' | 'YouTube';
  followers: number;
  engagement: number;
  postsThisWeek: number;
  verified: boolean;
  unlocked: boolean;
  unlockCost: number;
}

export interface StreamingIntegration {
  id: string;
  platform: 'Twitch' | 'YouTube Gaming' | 'Kick';
  subscribers: number;
  avgViewers: number;
  hoursStreamed: number;
  unlocked: boolean;
  unlockCost: number;
}

export interface BrandPartnership {
  id: string;
  brand: string;
  category: 'Apparel' | 'Gaming' | 'Energy' | 'Tech' | 'Food';
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  weeklyPay: number;
  bonusPerPost: number;
  requiresFollowers: number;
  requiresEngagement: number;
  active: boolean;
  weeksRemaining?: number;
}

export interface MediaAppearance {
  id: string;
  type: 'Podcast' | 'Interview' | 'Documentary' | 'Magazine';
  title: string;
  reputationBonus: number;
  followerBonus: number;
  payAmount: number;
  completed: boolean;
  availableAtWeek: number;
}

export interface StoryChoice {
  id: string;
  week: number;
  season: Season;
  title: string;
  description: string;
  options: {
    text: string;
    effects: {
      gpa?: number;
      reputation?: number;
      teamChemistry?: number;
      coachTrust?: number;
      fanSupport?: number;
      energy?: number;
      confidence?: number;
    };
  }[];
}

export type ItemCategory = 'gear' | 'character' | 'dorm';

export interface InventoryItem {
  id: string;
  name: string;
  category: ItemCategory;
  description: string;
  price: number;
  statBoosts?: Partial<PlayerStats>;
  equipped: boolean;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

export interface GameState {
  // Player Info
  profile: PlayerProfile;
  stats: PlayerStats;
  level: number;
  xp: number;
  xpToNextLevel: number;
  gpa: number;

  // Progression
  season: Season;
  phase: Phase;
  week: number;
  isStarter: boolean;
  isHighSchool: boolean;

  // Economy
  currency: Currency;

  // Energy & Schedule
  energy: number;
  maxEnergy: number;
  weeklyActivitiesDone: {
    training: boolean;
    classes: boolean;
    match: boolean;
  };

  // Scholarships & Deals
  currentScholarship: ScholarshipTier;
  scholarshipOffers: ScholarshipOffer[];
  activeNILDeals: NILDeal[];
  availableNILDeals: NILDeal[];

  // Reputation & Relationships
  reputation: number;
  teamChemistry: number;
  coachTrust: number;
  fanSupport: number;

  // History
  matchHistory: MatchResult[];
  choiceHistory: { choiceId: string; optionIndex: number }[];
  achievements: Achievement[];

  // Season Schedule
  seasonSchedule: ScheduledMatch[];
  regularSeasonWins: number;
  regularSeasonLosses: number;
  regularSeasonTies: number;

  // Traits & Perks
  unlockedTraits: string[];
  skillPoints: number;

  // Transfer
  transferHistory: string[];

  // Inventory & Customization
  inventory: InventoryItem[];

  // Integrations
  socialMedia: SocialMediaIntegration[];
  streaming: StreamingIntegration[];
  brandPartnerships: BrandPartnership[];
  mediaAppearances: MediaAppearance[];
  contentCreationSkill: number;
}
