// Static game data - colleges, NIL deals, story choices, etc.

import { type NILDeal, type StoryChoice, type Achievement, type ScholarshipOffer } from '@/types/game';

export const COLLEGES = [
  'UCLA',
  'Stanford',
  'North Carolina',
  'Duke',
  'Michigan',
  'Notre Dame',
  'Virginia',
  'Indiana',
  'Georgetown',
  'Wake Forest',
];

export const NIL_DEALS_POOL: Omit<NILDeal, 'id'>[] = [
  {
    brand: 'Nike',
    tier: 'platinum',
    weeklyPay: 2000,
    weeksRemaining: 12,
    requirements: { minReputation: 150, minPerformance: 85 },
  },
  {
    brand: 'Adidas',
    tier: 'gold',
    weeklyPay: 1200,
    weeksRemaining: 10,
    requirements: { minReputation: 100, minPerformance: 75 },
  },
  {
    brand: 'Gatorade',
    tier: 'gold',
    weeklyPay: 1000,
    weeksRemaining: 8,
    requirements: { minReputation: 90, minPerformance: 70 },
  },
  {
    brand: 'Local Sports Shop',
    tier: 'silver',
    weeklyPay: 500,
    weeksRemaining: 8,
    requirements: { minReputation: 50, minPerformance: 65 },
  },
  {
    brand: 'Energy Drink Co',
    tier: 'silver',
    weeklyPay: 600,
    weeksRemaining: 6,
    requirements: { minReputation: 60, minPerformance: 65 },
  },
  {
    brand: 'Campus Pizza',
    tier: 'bronze',
    weeklyPay: 200,
    weeksRemaining: 4,
    requirements: { minReputation: 20, minPerformance: 55 },
  },
  {
    brand: 'Fitness Gym',
    tier: 'bronze',
    weeklyPay: 250,
    weeksRemaining: 6,
    requirements: { minReputation: 25, minPerformance: 60 },
  },
];

export const STORY_CHOICES: StoryChoice[] = [
  {
    id: 'week2-party',
    week: 2,
    season: 'Freshman',
    title: 'The Big Party',
    description: 'Your teammates invite you to a huge party the night before an important match.',
    options: [
      {
        text: 'Go to the party and have fun',
        effects: { teamChemistry: 10, energy: -15, coachTrust: -5 },
      },
      {
        text: 'Skip it and rest for the match',
        effects: { energy: 10, coachTrust: 5, teamChemistry: -5 },
      },
      {
        text: 'Stop by briefly then leave',
        effects: { teamChemistry: 5, energy: -5 },
      },
    ],
  },
  {
    id: 'week5-academic',
    week: 5,
    season: 'Freshman',
    title: 'Midterm Crisis',
    description: 'You have a major exam the same week as an important tournament.',
    options: [
      {
        text: 'Focus on the exam',
        effects: { gpa: 0.2, coachTrust: -5, confidence: -5 },
      },
      {
        text: 'Prioritize soccer',
        effects: { gpa: -0.1, confidence: 5, coachTrust: 5 },
      },
      {
        text: 'Try to balance both',
        effects: { gpa: 0.1, energy: -10 },
      },
    ],
  },
  {
    id: 'week8-leadership',
    week: 8,
    season: 'Sophomore',
    title: 'Team Conflict',
    description: 'Two key players have a heated argument. As a rising leader, they look to you.',
    options: [
      {
        text: 'Mediate and bring them together',
        effects: { teamChemistry: 15, coachTrust: 10, energy: -5 },
      },
      {
        text: 'Stay out of it',
        effects: { teamChemistry: -10 },
      },
      {
        text: 'Pick a side',
        effects: { teamChemistry: -5, fanSupport: 5 },
      },
    ],
  },
  {
    id: 'week3-injury',
    week: 3,
    season: 'Junior',
    title: 'Minor Injury',
    description: "You're feeling pain in your knee but the championship game is in two days.",
    options: [
      {
        text: 'Rest and miss the game',
        effects: { energy: 20, coachTrust: -10, fanSupport: -10 },
      },
      {
        text: 'Push through and play',
        effects: { confidence: 10, energy: -20, reputation: 5 },
      },
      {
        text: 'Get treatment and play limited minutes',
        effects: { coachTrust: 5, energy: -5 },
      },
    ],
  },
  {
    id: 'week6-media',
    week: 6,
    season: 'Senior',
    title: 'Media Attention',
    description: 'National media wants an exclusive interview. Your coach prefers you stay focused.',
    options: [
      {
        text: 'Do the interview',
        effects: { fanSupport: 15, reputation: 10, coachTrust: -10 },
      },
      {
        text: 'Decline respectfully',
        effects: { coachTrust: 10, fanSupport: -5 },
      },
      {
        text: 'Ask coach for permission first',
        effects: { coachTrust: 15, reputation: 5 },
      },
    ],
  },
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'starter',
    title: 'Starting Lineup',
    description: 'Become a starting player',
    unlocked: false,
    progress: 0,
    target: 1,
  },
  {
    id: 'full-scholarship',
    title: 'Full Ride',
    description: 'Earn a full scholarship',
    unlocked: false,
    progress: 0,
    target: 1,
  },
  {
    id: 'first-nil',
    title: 'Getting Paid',
    description: 'Sign your first NIL deal',
    unlocked: false,
    progress: 0,
    target: 1,
  },
  {
    id: 'perfect-gpa',
    title: 'Scholar Athlete',
    description: 'Maintain a 4.0 GPA',
    unlocked: false,
    progress: 0,
    target: 1,
  },
  {
    id: 'tournament-win',
    title: 'Champion',
    description: 'Win a tournament',
    unlocked: false,
    progress: 0,
    target: 1,
  },
  {
    id: 'max-level',
    title: 'Elite Player',
    description: 'Reach level 20',
    unlocked: false,
    progress: 0,
    target: 20,
  },
  {
    id: 'platinum-nil',
    title: 'Superstar',
    description: 'Sign a platinum-tier NIL deal',
    unlocked: false,
    progress: 0,
    target: 1,
  },
  {
    id: 'graduate',
    title: 'College Legend',
    description: 'Complete all four seasons and graduate',
    unlocked: false,
    progress: 0,
    target: 4,
  },
];

export const generateScholarshipOffers = (
  currentCollege: string,
  reputation: number
): ScholarshipOffer[] => {
  const offers: ScholarshipOffer[] = [];
  const availableColleges = COLLEGES.filter(c => c !== currentCollege);

  if (reputation > 80) {
    offers.push({
      id: `full-${Date.now()}`,
      college: availableColleges[Math.floor(Math.random() * availableColleges.length)],
      tier: 'full',
      value: 50000,
      requirements: ['Maintain 3.0 GPA', 'Start in 80% of matches'],
    });
  }

  if (reputation > 50) {
    offers.push({
      id: `partial-${Date.now()}`,
      college: availableColleges[Math.floor(Math.random() * availableColleges.length)],
      tier: 'partial',
      value: 25000,
      requirements: ['Maintain 2.5 GPA', 'Regular playing time'],
    });
  }

  return offers;
};
