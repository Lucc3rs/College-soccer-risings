// Game engine logic and calculations

import { type PlayerStats, type Position, type GameState, type Season, type MatchResult, type ScheduledMatch } from '@/types/game';

// Position-based starting stats
export const getStartingStats = (position: Position): PlayerStats => {
  const baseStats = {
    pace: 60,
    shooting: 60,
    passing: 60,
    dribbling: 60,
    strength: 60,
    stamina: 60,
    defending: 60,
    confidence: 60,
    leadership: 50,
  };

  const positionBonus: Record<Position, Partial<PlayerStats>> = {
    ST: { shooting: 15, pace: 10, strength: 5 },
    CAM: { passing: 15, dribbling: 10, shooting: 5 },
    CM: { passing: 10, stamina: 10, dribbling: 5, defending: 5 },
    CDM: { defending: 15, strength: 10, stamina: 5 },
    CB: { defending: 15, strength: 15, pace: -5 },
    GK: { defending: 20, strength: 10, pace: -10, shooting: -20, dribbling: -10 },
  };

  return {
    ...baseStats,
    ...Object.fromEntries(
      Object.entries(positionBonus[position]).map(([key, value]) => [
        key,
        baseStats[key as keyof PlayerStats] + value,
      ])
    ),
  } as PlayerStats;
};

// XP and leveling
export const calculateXPForLevel = (level: number): number => {
  return Math.floor(100 * Math.pow(1.15, level - 1));
};

export const calculateLevelFromXP = (xp: number): number => {
  let level = 1;
  let totalXP = 0;
  while (totalXP + calculateXPForLevel(level) <= xp) {
    totalXP += calculateXPForLevel(level);
    level++;
  }
  return level;
};

// Match simulation
export const simulateMatch = (
  playerStats: PlayerStats,
  position: Position,
  opponentDifficulty: number
): MatchResult => {
  const statAvg = Object.values(playerStats).reduce((a, b) => a + b, 0) / 9;
  const performanceScore = statAvg + Math.random() * 20 - opponentDifficulty;

  const won = performanceScore > 65;
  const performance = Math.min(100, Math.max(0, performanceScore));

  const xpEarned = Math.floor(50 + performance * 0.5 + (won ? 25 : 0));
  const reputationEarned = Math.floor(performance / 10 + (won ? 5 : 0));

  const highlights = generateMatchHighlights(position, performance, won);

  return {
    won,
    performance,
    xpEarned,
    reputationEarned,
    highlights,
  };
};

const generateMatchHighlights = (position: Position, performance: number, won: boolean): string[] => {
  const highlights: string[] = [];

  if (performance > 80) {
    const excellent = {
      ST: 'Scored a spectacular goal!',
      CAM: 'Delivered a perfect through-ball assist!',
      CM: 'Controlled the midfield brilliantly!',
      CDM: 'Broke up multiple attacks!',
      CB: 'Made crucial defensive clearances!',
      GK: 'Made incredible saves!',
    };
    highlights.push(excellent[position]);
  }

  if (performance > 70) {
    highlights.push('Solid performance throughout the match');
  }

  if (won) {
    highlights.push('Team victory!');
  } else if (performance > 60) {
    highlights.push('Strong individual effort despite the loss');
  }

  if (performance < 50) {
    highlights.push('Struggled to make an impact');
  }

  return highlights.length > 0 ? highlights : ['Participated in the match'];
};

// Training rewards
export const getTrainingReward = (minigame: string, performance: number): {
  xp: number;
  statBonus: Partial<PlayerStats>;
} => {
  const baseXP = 20 + performance;

  const statMappings: Record<string, keyof PlayerStats> = {
    shooting: 'shooting',
    passing: 'passing',
    dribbling: 'dribbling',
    stamina: 'stamina',
    reflexes: 'defending',
  };

  const statBonus = {
    [statMappings[minigame]]: Math.floor(performance / 20),
  };

  return { xp: baseXP, statBonus };
};

// Scholarship eligibility
export const calculateScholarshipEligibility = (state: GameState): 'none' | 'partial' | 'full' => {
  const statAvg = Object.values(state.stats).reduce((a, b) => a + b, 0) / 9;
  const overallScore = statAvg * 0.4 + state.gpa * 10 + state.reputation * 0.3;

  if (overallScore > 85) return 'full';
  if (overallScore > 70) return 'partial';
  return 'none';
};

// NIL deal eligibility
export const isEligibleForNILDeal = (
  state: GameState,
  deal: { requirements: { minReputation: number; minPerformance: number } }
): boolean => {
  const statAvg = Object.values(state.stats).reduce((a, b) => a + b, 0) / 9;
  return state.reputation >= deal.requirements.minReputation && statAvg >= deal.requirements.minPerformance;
};

// Season progression
export const advanceWeek = (state: GameState): Partial<GameState> => {
  const newWeek = state.week + 1;
  const updates: Partial<GameState> = {
    week: newWeek,
    energy: state.maxEnergy,
    weeklyActivitiesDone: {
      training: false,
      classes: false,
      match: false,
    },
  };

  // Process NIL deals
  const updatedNILDeals = state.activeNILDeals.map(deal => ({
    ...deal,
    weeksRemaining: deal.weeksRemaining - 1,
  })).filter(deal => deal.weeksRemaining > 0);

  const nilIncome = state.activeNILDeals.reduce((sum, deal) => sum + deal.weeklyPay, 0);

  // Process brand partnerships
  let brandIncome = 0;
  const updatedBrandPartnerships = (state.brandPartnerships || []).map(brand => {
    if (brand.active && brand.weeksRemaining) {
      const newWeeksRemaining = brand.weeksRemaining - 1;
      if (newWeeksRemaining > 0) {
        brandIncome += brand.weeklyPay;
        return { ...brand, weeksRemaining: newWeeksRemaining };
      } else {
        return { ...brand, active: false, weeksRemaining: undefined };
      }
    }
    return brand;
  });

  // Reset social media post counts
  const resetSocialMedia = (state.socialMedia || []).map(sm => ({
    ...sm,
    postsThisWeek: 0,
  }));

  updates.activeNILDeals = updatedNILDeals;
  updates.brandPartnerships = updatedBrandPartnerships;
  updates.socialMedia = resetSocialMedia;
  updates.currency = {
    ...state.currency,
    nilMoney: state.currency.nilMoney + nilIncome + brandIncome,
  };

  // Check for phase/season transitions
  if (state.isHighSchool && newWeek > 20) {
    // High school season complete - transition to college selection
    updates.phase = 'College Selection';
  } else if (newWeek > 20 && state.phase === 'Regular Season') {
    // Check record for playoff eligibility (need 10+ wins)
    if (state.regularSeasonWins >= 10) {
      // Generate conference playoff schedule
      const conferenceSchedule = generateConferencePlayoffSchedule(state.level, 21);
      updates.seasonSchedule = [...(state.seasonSchedule || []), ...conferenceSchedule];
      updates.phase = 'Conference Playoffs';
    } else {
      updates.phase = 'Off-Season';
    }
  } else if (state.phase === 'Conference Playoffs') {
    // Check if won conference playoffs (need to win all 3 games)
    const conferenceGames = (state.seasonSchedule || []).filter(m => m.phase === 'Conference Playoffs' && m.completed);
    const conferenceWins = conferenceGames.filter(m => m.result?.won).length;

    if (conferenceWins === 3) {
      // Won conference, advance to national tournament
      const nationalSchedule = generateNationalTournamentSchedule(state.level, newWeek);
      updates.seasonSchedule = [...(state.seasonSchedule || []), ...nationalSchedule];
      updates.phase = 'National Tournament';
    } else {
      // Lost in conference playoffs
      updates.phase = 'Off-Season';
    }
  } else if (state.phase === 'National Tournament') {
    updates.phase = 'Off-Season';
  }

  return updates;
};

export const advanceSeason = (currentSeason: Season): Season | null => {
  const order: Season[] = ['High School Senior', 'Freshman', 'Sophomore', 'Junior', 'Senior'];
  const currentIndex = order.indexOf(currentSeason);
  return currentIndex < 4 ? order[currentIndex + 1] : null;
};

// Energy costs
export const ENERGY_COSTS = {
  training: 30,
  classes: 20,
  match: 40,
} as const;

// Team names for opponents
const TEAM_NAMES = [
  'Eagles', 'Tigers', 'Lions', 'Bears', 'Wolves', 'Hawks', 'Panthers', 'Cougars',
  'Wildcats', 'Bulldogs', 'Titans', 'Spartans', 'Warriors', 'Knights', 'Dragons',
  'Falcons', 'Mustangs', 'Jaguars', 'Vipers', 'Rams', 'Cobras', 'Thunder',
  'Storm', 'Lightning', 'Fury', 'Legends', 'Phoenix', 'Crusaders'
];

const CITY_NAMES = [
  'North', 'South', 'East', 'West', 'Central', 'Mountain', 'Valley', 'River',
  'Lake', 'Oak', 'Pine', 'Maple', 'Cedar', 'Willow', 'Spring', 'Summit',
  'Harbor', 'Bay', 'Ridge', 'Park', 'Hill', 'Grove', 'Forest', 'Meadow'
];

// Generate season schedule with 20 regular season games
export const generateSeasonSchedule = (playerLevel: number): ScheduledMatch[] => {
  const schedule: ScheduledMatch[] = [];

  // Generate 20 regular season games with random difficulties each week
  for (let week = 1; week <= 20; week++) {
    // Generate opponent name
    const city = CITY_NAMES[Math.floor(Math.random() * CITY_NAMES.length)];
    const team = TEAM_NAMES[Math.floor(Math.random() * TEAM_NAMES.length)];
    const opponent = `${city} ${team}`;

    // Random difficulty for each match (40-85 range with player level influence)
    const baseDifficulty = 40 + (playerLevel * 2);
    const randomVariation = Math.floor(Math.random() * 30); // 0 to 30 random variation
    const opponentDifficulty = Math.max(40, Math.min(85, baseDifficulty + randomVariation));

    schedule.push({
      id: `regular-${week}`,
      week,
      opponent,
      opponentDifficulty,
      phase: 'Regular Season',
      completed: false,
    });
  }

  return schedule;
};

// Generate conference playoff schedule (single elimination, 3 rounds)
export const generateConferencePlayoffSchedule = (playerLevel: number, startWeek: number): ScheduledMatch[] => {
  const schedule: ScheduledMatch[] = [];
  const rounds = ['Quarterfinal', 'Semifinal', 'Conference Final'];

  for (let i = 0; i < 3; i++) {
    const city = CITY_NAMES[Math.floor(Math.random() * CITY_NAMES.length)];
    const team = TEAM_NAMES[Math.floor(Math.random() * TEAM_NAMES.length)];
    const opponent = `${city} ${team}`;

    // Playoff teams are harder (75-90 difficulty)
    const opponentDifficulty = 75 + Math.floor(Math.random() * 15) + (i * 3);

    schedule.push({
      id: `conference-${i + 1}`,
      week: startWeek + i,
      opponent: `${opponent} (${rounds[i]})`,
      opponentDifficulty,
      phase: 'Conference Playoffs',
      completed: false,
    });
  }

  return schedule;
};

// Generate national tournament schedule (single elimination, 4 rounds)
export const generateNationalTournamentSchedule = (playerLevel: number, startWeek: number): ScheduledMatch[] => {
  const schedule: ScheduledMatch[] = [];
  const rounds = ['Sweet 16', 'Elite 8', 'Final Four', 'National Championship'];

  for (let i = 0; i < 4; i++) {
    const city = CITY_NAMES[Math.floor(Math.random() * CITY_NAMES.length)];
    const team = TEAM_NAMES[Math.floor(Math.random() * TEAM_NAMES.length)];
    const opponent = `${city} ${team}`;

    // National tournament teams are very hard (80-95 difficulty)
    const opponentDifficulty = 80 + Math.floor(Math.random() * 15) + (i * 2);

    schedule.push({
      id: `national-${i + 1}`,
      week: startWeek + i,
      opponent: `${opponent} (${rounds[i]})`,
      opponentDifficulty,
      phase: 'National Tournament',
      completed: false,
    });
  }

  return schedule;
};
